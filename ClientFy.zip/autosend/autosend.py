#!/usr/bin/env python3
"""
ClientFy Авторассылка (изолированный модуль).
Ищет Telegram-лички из результатов YouTube-поиска и рассылает шаблон от имени user-аккаунта (Telethon).

Использование:
  python3 autosend.py collect --user-id <id>   - собрать получателей для пользователя (из настроек бота)
  python3 autosend.py list --user-id <id>      - показать получателей
  python3 autosend.py send --user-id <id>      - отправить сообщения (нужна Telethon-сессия)

Без --user-id используется общий config.json (старый режим).
"""
import argparse
import asyncio
import json
import random
import re
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Set

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(ROOT / "bot"))

# reuse existing search logic + storage
try:
    from config import load_env  # type: ignore
    from youtube import search_channels  # type: ignore
    from storage import get_autosend  # type: ignore
    load_env()
except Exception as e:
    print("Ошибка импорта модулей бота:", e)
    print("Запускайте из ClientFy/autosend или убедитесь, что ClientFy/bot доступен.")
    sys.exit(1)

CONFIG_PATH = HERE / "config.json"
TG_LINK_RE = re.compile(r"(?:https?://)?t\.me/([A-Za-z0-9_]{4,})", re.I)
AT_RE = re.compile(r"(?<![A-Za-z0-9_])@([A-Za-z0-9_]{4,})")


def load_json(path: Path, default):
    if not path.exists():
        return default
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default


def save_json(path: Path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def targets_path(user_id) -> Path:
    if user_id is None:
        return HERE / "targets.json"
    return HERE / f"targets_{user_id}.json"


def sent_path(user_id) -> Path:
    if user_id is None:
        return HERE / "sent.json"
    return HERE / f"sent_{user_id}.json"


def load_config() -> Dict[str, Any]:
    if not CONFIG_PATH.exists():
        return {}
    return load_json(CONFIG_PATH, {})


def merge_cfg_for_user(user_id) -> Dict[str, Any]:
    """Настройки рассылки: приоритет у настроек бота (runtime.json), затем config.json."""
    cfg = dict(load_config())
    if user_id is not None:
        try:
            ac = get_autosend(str(user_id))
        except Exception:
            ac = {}
        topics = ac.get("topics") or []
        tmpl = ac.get("template") or ""
        if topics:
            cfg["topics"] = topics
        if tmpl:
            cfg["template"] = tmpl
    return cfg


def is_personal_tg_username(username: str) -> bool:
    u = (username or "").strip().lstrip("@")
    if not u:
        return False
    low = u.lower()
    if low in {"joinchat", "share", "iv", "s", "c", "addstickers", "addemoji", "proxy", "socks", "setlanguage"}:
        return False
    if "+" in u:
        return False
    return bool(re.fullmatch(r"[A-Za-z0-9_]{4,}", u))


def extract_tg_personals(links: List[str], text: str = "") -> List[str]:
    found: List[str] = []
    blob = "\n".join(links or []) + "\n" + (text or "")
    for m in TG_LINK_RE.finditer(blob):
        u = m.group(1)
        if is_personal_tg_username(u):
            found.append(u)
    for m in AT_RE.finditer(blob):
        u = m.group(1)
        if is_personal_tg_username(u):
            found.append(u)
    seen: Set[str] = set()
    out = []
    for u in found:
        k = u.lower()
        if k in seen:
            continue
        seen.add(k)
        out.append(u)
    return out


def collect_targets(cfg: Dict[str, Any], user_id=None) -> List[Dict[str, Any]]:
    topics = cfg.get("topics") or []
    if isinstance(topics, str):
        topics = [topics]
    topics = [str(t).strip() for t in topics if str(t).strip()]
    if not topics:
        print("Нет тем в настройках (topics).")
        return []

    s = cfg.get("search") or {}
    days = s.get("days", 7)
    try:
        days = int(days) if days not in (None, "", 0, "0") else None
    except Exception:
        days = None
    count = int(s.get("count") or 5)
    req_ch = bool(s.get("requireChannelLink"))
    req_rv = bool(s.get("requireRecentLink"))
    subs_min = s.get("subsMin")
    subs_max = s.get("subsMax")
    try:
        subs_min = int(subs_min) if subs_min is not None and subs_min != "" else None
    except Exception:
        subs_min = None
    try:
        subs_max = int(subs_max) if subs_max is not None and subs_max != "" else None
    except Exception:
        subs_max = None

    all_targets: Dict[str, Dict[str, Any]] = {}
    for topic in topics:
        print(f"\nПоиск по теме: {topic}")
        try:
            results = search_channels(
                query=topic,
                days=days,
                require_channel_link=req_ch,
                require_recent_link=req_rv,
                limit=max(1, min(count, 50)),
                subs_min=subs_min,
                subs_max=subs_max,
            )
        except Exception as e:
            print("  Ошибка поиска:", e)
            continue
        print(f"  Каналов найдено: {len(results)}")
        for c in results:
            links = list(c.get("links") or [])
            desc = (c.get("description") or "")
            for v in (c.get("recentVideos") or []):
                desc += "\n" + (v.get("description") or "")
            personals = extract_tg_personals(links, desc)
            for uname in personals:
                key = uname.lower()
                if key not in all_targets:
                    all_targets[key] = {
                        "username": uname,
                        "source_topic": topic,
                        "source_channel": c.get("title"),
                        "source_channel_url": c.get("url"),
                    }
    targets = list(all_targets.values())
    save_json(targets_path(user_id), {"targets": targets, "user_id": str(user_id) if user_id else None,
                                      "updated_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())})
    print(f"\nИтого уникальных Telegram-контактов: {len(targets)}")
    print(f"Сохранено: {targets_path(user_id)}")
    return targets


def cmd_collect(args):
    cfg = merge_cfg_for_user(args.user_id)
    collect_targets(cfg, args.user_id)


def cmd_list(args):
    data = load_json(targets_path(args.user_id), {"targets": []})
    targets = data.get("targets") or []
    sent = load_json(sent_path(args.user_id), {"sent": []})
    sent_set = {str(x.get("username", "")).lower() for x in (sent.get("sent") or [])}
    if not targets:
        print("Нет получателей. Сначала: python3 autosend.py collect --user-id <id>")
        return
    for i, t in enumerate(targets, 1):
        u = t.get("username")
        mark = " [отправлено]" if str(u).lower() in sent_set else ""
        src = t.get("source_channel") or t.get("source_topic") or ""
        print(f"{i}. @{u}{mark} — {src}")
    print(f"\nВсего: {len(targets)}")


async def _send_async(cfg: Dict[str, Any], user_id=None):
    try:
        from telethon import TelegramClient
        from telethon.errors import FloodWaitError, UserPrivacyRestrictedError, PeerFloodError
    except Exception:
        print("Telethon не установлен. Установите: pip install -r requirements.txt")
        sys.exit(1)

    api_id = int(cfg.get("api_id") or 0)
    api_hash = str(cfg.get("api_hash") or "")
    phone = str(cfg.get("phone") or "")
    session_name = str(cfg.get("session_name") or f"clientfy_user_{user_id}" if user_id else "clientfy_user")
    if not api_id or not api_hash or not phone:
        print("Заполните api_id, api_hash, phone в config.json")
        sys.exit(1)

    targets = (load_json(targets_path(user_id), {"targets": []}) or {}).get("targets") or []
    if not targets:
        print("Нет получателей. Сначала: python3 autosend.py collect --user-id <id>")
        return

    sent_data = load_json(sent_path(user_id), {"sent": []})
    sent_list = sent_data.get("sent") or []
    sent_set = {str(x.get("username", "")).lower() for x in sent_list}

    template = str(cfg.get("template") or "Здравствуйте! Увидел ваш канал «{title}» ({url}).")
    limits = cfg.get("limits") or {}
    dmin = max(5, int(limits.get("delay_seconds_min") or 20))
    dmax = max(dmin, int(limits.get("delay_seconds_max") or 30))
    max_per_run = max(1, int(limits.get("max_per_run") or 30))

    client = TelegramClient(str(HERE / session_name), api_id, api_hash)
    await client.start(phone=phone)

    sent_now = 0
    for t in targets:
        if sent_now >= max_per_run:
            print(f"Достигнут лимит за запуск: {max_per_run}")
            break
        uname = str(t.get("username") or "")
        key = uname.lower()
        if not uname or key in sent_set:
            continue
        msg = template.format(
            title=t.get("source_channel") or "",
            url=t.get("source_channel_url") or "",
            username=uname,
            topic=t.get("source_topic") or "",
        )
        try:
            await client.send_message(uname, msg)
            print(f"OK @{uname}")
            sent_list.append({"username": uname, "at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "status": "ok"})
            sent_set.add(key)
            sent_now += 1
            save_json(sent_path(user_id), {"sent": sent_list})
        except FloodWaitError as e:
            wait_s = int(getattr(e, "seconds", 60))
            print(f"FloodWait {wait_s}s — остановка. Повторите позже.")
            break
        except PeerFloodError:
            print("PeerFloodError: Telegram ограничил рассылку с аккаунта. Остановлено.")
            break
        except UserPrivacyRestrictedError:
            print(f"SKIP @{uname}: ограничения приватности")
            sent_list.append({"username": uname, "at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "status": "privacy"})
            sent_set.add(key)
            save_json(sent_path(user_id), {"sent": sent_list})
        except Exception as e:
            print(f"ERR @{uname}: {e}")
            sent_list.append({"username": uname, "at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "status": "error", "error": str(e)})
            sent_set.add(key)
            save_json(sent_path(user_id), {"sent": sent_list})
        await asyncio.sleep(random.randint(dmin, dmax))

    await client.disconnect()
    print(f"Готово. Отправлено в этом запуске: {sent_now}")


def cmd_send(args):
    cfg = merge_cfg_for_user(args.user_id)
    asyncio.run(_send_async(cfg, args.user_id))


def main():
    ap = argparse.ArgumentParser(description="ClientFy autosend module")
    ap.add_argument("cmd", choices=["collect", "list", "send"], help="Команда")
    ap.add_argument("--user-id", default=None, help="ID пользователя (настройки из бота)")
    args = ap.parse_args()
    if args.cmd == "collect":
        cmd_collect(args)
    elif args.cmd == "list":
        cmd_list(args)
    elif args.cmd == "send":
        cmd_send(args)


if __name__ == "__main__":
    main()
