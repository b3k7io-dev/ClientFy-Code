import os
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ENV_PATH = ROOT / ".env"


def load_env(path: Path = ENV_PATH) -> None:
    if not path.exists():
        return
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        k = k.strip()
        v = v.strip().strip('"').strip("'")
        if k and (k not in os.environ or os.environ.get(k) == ""):
            os.environ[k] = v


load_env()


def env(key: str, default: str = "") -> str:
    v = os.environ.get(key)
    return default if v is None or v == "" else v


YOUTUBE_API_KEY = env("YOUTUBE_API_KEY")
TELEGRAM_BOT_TOKEN = env("TELEGRAM_BOT_TOKEN")
TELEGRAM_BOT_USERNAME = env("TELEGRAM_BOT_USERNAME", "ClientFy_Robot")
TELEGRAM_CHANNEL_URL = env("TELEGRAM_CHANNEL_URL", "https://t.me/Client_Fy")
SUPPORT_URL = env("SUPPORT_URL", "https://t.me/tapaem_durova")
ADMIN_PASSWORD = env("ADMIN_PASSWORD")
OWNER_ID = str(env("OWNER_ID")).strip()

# MTProto (Telethon) credentials for user-account auth.
TELEGRAM_API_ID = int(env("TELEGRAM_API_ID", "0") or "0")
TELEGRAM_API_HASH = env("TELEGRAM_API_HASH")

# Secure auth gateway (web flow; no codes/passwords in chat)
AUTH_GATEWAY_HOST = env("AUTH_GATEWAY_HOST", "127.0.0.1")
AUTH_GATEWAY_PORT = int(env("AUTH_GATEWAY_PORT", "8765"))
AUTH_TOKEN_TTL = int(env("AUTH_TOKEN_TTL", "600"))
AUTH_GATEWAY_PUBLIC_URL = env("AUTH_GATEWAY_PUBLIC_URL", "")
AUTH_API_PUBLIC_URL = env("AUTH_API_PUBLIC_URL", "")
AUTH_MAX_CODE_ATTEMPTS = int(env("AUTH_MAX_CODE_ATTEMPTS", "5"))

SESSION_KEY_FILE = Path(env("SESSION_KEY_FILE", str(ROOT / "data" / ".session_key")))
if not SESSION_KEY_FILE.is_absolute():
    SESSION_KEY_FILE = (ROOT / SESSION_KEY_FILE).resolve()

FREE_LIMIT = int(env("FREE_LIMIT", "15"))
PRO_LIMIT = int(env("PRO_LIMIT", "50"))
PRO_PRICE_USD = float(env("PRO_PRICE_USD", "3"))
PRO_PRICE_STARS = int(env("PRO_PRICE_STARS", "150"))
MAX_LIMIT = int(env("MAX_LIMIT", "100"))
MAX_PRICE_USD = float(env("MAX_PRICE_USD", "6"))
MAX_PRICE_STARS = int(env("MAX_PRICE_STARS", "300"))

DATA_FILE = Path(env("DATA_FILE", str(ROOT / "data" / "runtime.json")))
if not DATA_FILE.is_absolute():
    DATA_FILE = (ROOT / DATA_FILE).resolve()
