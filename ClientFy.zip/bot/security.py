"""Security helpers for ClientFy Telegram account auth.

- One-time auth tokens (bound to a Telegram user id, with TTL).
- AES-256-GCM encryption for stored MTProto session strings.
"""

import base64
import json
import os
import secrets
import time
from pathlib import Path
from typing import Any, Dict, Optional

try:
    from Crypto.Cipher import AES
    from Crypto.Random import get_random_bytes
except Exception:
    from Cryptodome.Cipher import AES
    from Cryptodome.Random import get_random_bytes

from config import SESSION_KEY_FILE, AUTH_TOKEN_TTL


# ---------- Session key (encryption at rest) ----------

def _load_or_create_key() -> bytes:
    env_key = os.environ.get("SESSION_ENCRYPTION_KEY")
    if env_key:
        try:
            raw = base64.b64decode(env_key)
            if len(raw) == 32:
                return raw
        except Exception:
            pass
    path = SESSION_KEY_FILE
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        try:
            raw = base64.b64decode(path.read_text(encoding="utf-8").strip())
            if len(raw) == 32:
                return raw
        except Exception:
            pass
    raw = get_random_bytes(32)
    path.write_text(base64.b64encode(raw).decode("ascii"), encoding="utf-8")
    try:
        os.chmod(path, 0o600)
    except Exception:
        pass
    return raw


_SESSION_KEY = _load_or_create_key()


def encrypt_session(plaintext: str) -> str:
    if not plaintext:
        return ""
    nonce = get_random_bytes(12)
    cipher = AES.new(_SESSION_KEY, AES.MODE_GCM, nonce=nonce)
    ct, tag = cipher.encrypt_and_digest(plaintext.encode("utf-8"))
    blob = nonce + tag + ct
    return base64.b64encode(blob).decode("ascii")


def decrypt_session(token: str) -> str:
    if not token:
        return ""
    try:
        blob = base64.b64decode(token.encode("ascii"))
        nonce, tag, ct = blob[:12], blob[12:28], blob[28:]
        cipher = AES.new(_SESSION_KEY, AES.MODE_GCM, nonce=nonce)
        return cipher.decrypt_and_verify(ct, tag).decode("utf-8")
    except Exception:
        return ""


# ---------- One-time auth tokens ----------

_TOKENS: Dict[str, Dict[str, Any]] = {}


def create_token(user_id: str, ttl: int = AUTH_TOKEN_TTL) -> str:
    tok = secrets.token_urlsafe(32)
    _TOKENS[tok] = {
        "user_id": str(user_id),
        "created_at": time.time(),
        "expires_at": time.time() + ttl,
        "attempts": 0,
        "max_attempts": 5,
    }
    return tok


def get_token(tok: str) -> Optional[Dict[str, Any]]:
    rec = _TOKENS.get(tok)
    if not rec:
        return None
    if time.time() > rec["expires_at"]:
        _TOKENS.pop(tok, None)
        return None
    return rec


def touch_attempts(tok: str) -> int:
    rec = _TOKENS.get(tok)
    if not rec:
        return 0
    rec["attempts"] = rec.get("attempts", 0) + 1
    return rec["attempts"]


def revoke_token(tok: str) -> None:
    _TOKENS.pop(tok, None)


def cleanup_expired() -> None:
    now = time.time()
    for t in [k for k, v in _TOKENS.items() if v["expires_at"] < now]:
        _TOKENS.pop(t, None)
