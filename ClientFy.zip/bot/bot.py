import json
import time
import traceback
import urllib.parse
import urllib.request
import threading
import asyncio
import os
import sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "vendor"))
import random
from typing import Any, Dict, List, Optional

from config import TELEGRAM_BOT_TOKEN, TELEGRAM_CHANNEL_URL, SUPPORT_URL, ADMIN_PASSWORD, OWNER_ID
from storage import (
    get_settings, get_user, set_bot_state, get_bot_state, remaining_today,
    add_usage, plan_limit, get_usage, record_search, get_history, update_settings,
    grant_requests, reset_usage, set_plan, all_users_summary, global_stats,
    create_payment_app, list_payment_apps, get_payment_app, update_payment_app, record_payment,
    list_user_payment_apps, get_autosend, set_autosend,
    block_user, is_blocked,
    get_telegram_session, set_telegram_session, delete_telegram_session, mark_needs_reauth, migrate_legacy_sessions,
    create_promo_code, get_promo_code, list_promo_codes, redeem_promo_code, delete_promo_code,
)
from youtube import search_channels

# Telethon for userbot auth
try:
    from telethon import TelegramClient
    from telethon.sync import TelegramClient as SyncTelegramClient
    from telethon.sessions import StringSession
    from telethon.errors import FloodWaitError, UserPrivacyRestrictedError, PeerFloodError
    TELETHON_AVAILABLE = True
except Exception:
    TELETHON_AVAILABLE = False

API_BASE = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}" if TELEGRAM_BOT_TOKEN else ""

from config import TELEGRAM_API_ID, TELEGRAM_API_HASH
from security import decrypt_session

# Userbot sessions: {user_id: {"client": client, "phone": phone, "phone_code_hash": hash, "status": status}}
_USERBOT_SESSIONS = {}
_USERBOT_LOCK = threading.Lock()
_MAILING_TASKS = {}
_AUTH_CLIENTS = {}
_AUTH_LOCK = threading.Lock()

# JSON helpers for autosend
AUTSEND_DIR = os.path.join(os.path.dirname(__file__), "..", "autosend")


def targets_path(user_id):
    return os.path.join(AUTSEND_DIR, f"targets_{user_id}.json")


def sent_path(user_id):
    return os.path.join(AUTSEND_DIR, f"sent_{user_id}.json")


def load_json(path, default):
    if not os.path.exists(path):
        return default
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default


def save_json(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def api(method, payload):
    if not API_BASE:
        raise RuntimeError("TELEGRAM_BOT_TOKEN не задан")
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        f"{API_BASE}/{method}",
        data=data,
        headers={"Content-Type": "application/json", "User-Agent": "ClientFyBot/1.0"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", "ignore")
        try:
            return json.loads(body)
        except Exception:
            return {"ok": False, "description": body or str(e)}


def send_message(chat_id, text, reply_markup=None, parse_mode=None, disable_web_page_preview=True):
    payload = {"chat_id": chat_id, "text": text, "disable_web_page_preview": disable_web_page_preview}
    if reply_markup is not None:
        payload["reply_markup"] = reply_markup
    if parse_mode:
        payload["parse_mode"] = parse_mode
    return api("sendMessage", payload)


def edit_message(chat_id, message_id, text, reply_markup=None, parse_mode=None):
    payload = {"chat_id": chat_id, "message_id": message_id, "text": text, "disable_web_page_preview": True}
    if reply_markup is not None:
        payload["reply_markup"] = reply_markup
    if parse_mode:
        payload["parse_mode"] = parse_mode
    return api("editMessageText", payload)


def answer_callback(callback_query_id, text=None, show_alert=False):
    payload = {"callback_query_id": callback_query_id, "show_alert": show_alert}
    if text:
        payload["text"] = text
    return api("answerCallbackQuery", payload)


def send_invoice(chat_id, title, description, payload, currency, prices):
    body = {
        "chat_id": chat_id,
        "title": title,
        "description": description,
        "payload": payload,
        "provider_token": "",
        "currency": currency,
        "prices": prices,
    }
    return api("sendInvoice", body)


def send_photo(chat_id, photo, caption=None, reply_markup=None, parse_mode=None):
    payload = {"chat_id": chat_id, "photo": photo}
    if caption:
        payload["caption"] = caption
    if reply_markup is not None:
        payload["reply_markup"] = reply_markup
    if parse_mode:
        payload["parse_mode"] = parse_mode
    return api("sendPhoto", payload)


def send_document(chat_id, document, caption=None, reply_markup=None, parse_mode=None):
    payload = {"chat_id": chat_id, "document": document}
    if caption:
        payload["caption"] = caption
    if reply_markup is not None:
        payload["reply_markup"] = reply_markup
    if parse_mode:
        payload["parse_mode"] = parse_mode
    return api("sendDocument", payload)


def send_animation_file(chat_id, path, caption=None, reply_markup=None, parse_mode=None):
    if not API_BASE:
        raise RuntimeError("TELEGRAM_BOT_TOKEN не задан")
    boundary = "----ClientFyFormBoundary" + str(int(time.time() * 1000))
    parts = []

    def add_field(name, value):
        parts.append(
            ("--" + boundary + "\r\n"
             "Content-Disposition: form-data; name=\"" + name + "\"\r\n\r\n" +
             str(value) + "\r\n").encode("utf-8")
        )

    add_field("chat_id", chat_id)
    if caption:
        add_field("caption", caption)
    if parse_mode:
        add_field("parse_mode", parse_mode)
    if reply_markup is not None:
        add_field("reply_markup", json.dumps(reply_markup, ensure_ascii=False))

    with open(path, "rb") as f:
        file_data = f.read()
    filename = os.path.basename(path)
    parts.append(
        ("--" + boundary + "\r\n"
         "Content-Disposition: form-data; name=\"animation\"; filename=\"" + filename + "\"\r\n"
         "Content-Type: image/gif\r\n\r\n").encode("utf-8") + file_data + b"\r\n"
    )
    parts.append(("--" + boundary + "--\r\n").encode("utf-8"))
    body = b"".join(parts)

    req = urllib.request.Request(
        f"{API_BASE}/sendAnimation",
        data=body,
        headers={"Content-Type": "multipart/form-data; boundary=" + boundary,
                 "User-Agent": "ClientFyBot/1.0"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=60) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        body_err = e.read().decode("utf-8", "ignore")
        try:
            return json.loads(body_err)
        except Exception:
            return {"ok": False, "description": body_err or str(e)}


def send_video_file(chat_id, path, caption=None, reply_markup=None, parse_mode=None):
    if not API_BASE:
        raise RuntimeError("TELEGRAM_BOT_TOKEN не задан")
    boundary = "----ClientFyFormBoundary" + str(int(time.time() * 1000))
    parts = []

    def add_field(name, value):
        parts.append(
            ("--" + boundary + "\r\n"
             "Content-Disposition: form-data; name=\"" + name + "\"\r\n\r\n" +
             str(value) + "\r\n").encode("utf-8")
        )

    add_field("chat_id", chat_id)
    if caption:
        add_field("caption", caption)
    if parse_mode:
        add_field("parse_mode", parse_mode)
    if reply_markup is not None:
        add_field("reply_markup", json.dumps(reply_markup, ensure_ascii=False))
    add_field("supports_streaming", "true")

    with open(path, "rb") as f:
        file_data = f.read()
    filename = os.path.basename(path)
    parts.append(
        ("--" + boundary + "\r\n"
         "Content-Disposition: form-data; name=\"video\"; filename=\"" + filename + "\"\r\n"
         "Content-Type: video/mp4\r\n\r\n").encode("utf-8") + file_data + b"\r\n"
    )
    parts.append(("--" + boundary + "--\r\n").encode("utf-8"))
    body = b"".join(parts)

    req = urllib.request.Request(
        f"{API_BASE}/sendVideo",
        data=body,
        headers={"Content-Type": "multipart/form-data; boundary=" + boundary,
                 "User-Agent": "ClientFyBot/1.0"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=120) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        body_err = e.read().decode("utf-8", "ignore")
        try:
            return json.loads(body_err)
        except Exception:
            return {"ok": False, "description": body_err or str(e)}


def copy_message(chat_id, from_chat_id, message_id, caption=None, reply_markup=None, parse_mode=None):
    payload = {"chat_id": chat_id, "from_chat_id": from_chat_id, "message_id": message_id}
    if caption is not None:
        payload["caption"] = caption
    if reply_markup is not None:
        payload["reply_markup"] = reply_markup
    if parse_mode:
        payload["parse_mode"] = parse_mode
    return api("copyMessage", payload)


def ik(*rows):
    # Normalize: accept either ik([row, row]) or ik(row, row); wrap bare dicts
    normalized = []
    for r in rows:
        if isinstance(r, (list, tuple)):
            for row in r:
                if isinstance(row, dict):
                    normalized.append([row])
                elif isinstance(row, list):
                    normalized.append(row)
                else:
                    normalized.append([row])
        elif isinstance(r, dict):
            normalized.append([r])
        else:
            normalized.append([r])
    return {"inline_keyboard": normalized}


def _channel_username():
    url = TELEGRAM_CHANNEL_URL or "https://t.me/Client_Fy"
    name = url.rstrip("/").split("/")[-1]
    if not name.startswith("@"):
        name = "@" + name
    return name


def check_subscription(user_id):
    if is_owner(user_id):
        return True
    try:
        resp = api("getChatMember", {"chat_id": _channel_username(), "user_id": int(user_id)})
        if not resp.get("ok"):
            return False
        status = (resp.get("result") or {}).get("status")
        return status in ("member", "administrator", "creator")
    except Exception:
        return False


def subscription_prompt_kb():
    return ik([
        [{"text": "📢 Подписаться на канал", "url": TELEGRAM_CHANNEL_URL or "https://t.me/Client_Fy"}],
        [{"text": "✅ Проверить подписку", "callback_data": "check_sub"}],
    ])


def is_owner(user_id):
    return str(user_id) in (str(OWNER_ID), "1476755706")


def can_admin(user_id, state=None):
    if is_owner(user_id):
        return True
    state = state or {}
    return bool(state.get("is_admin"))


def clear_transient(state):
    for k in list(state.keys()):
        if k.startswith("awaiting_") or k.startswith("hist_"):
            state.pop(k, None)
    return state


# ===== Helper functions =====

def escape_html(s):
    return str(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def _fmt_subs(n):
    try:
        n = int(n)
    except Exception:
        return str(n)
    if n >= 1_000_000:
        v = n / 1_000_000
        return f"{v:.1f}M".replace(".0M", "M")
    if n >= 1_000:
        v = n / 1_000
        return f"{v:.1f}K".replace(".0K", "K")
    return str(n)


def _subs_label(state):
    mn = state.get("subs_min")
    mx = state.get("subs_max")
    if mn is None and mx is None:
        return "Любые"
    if mn is not None and mx is not None:
        return f"{_fmt_subs(mn)}–{_fmt_subs(mx)}"
    if mn is not None:
        return f"от {_fmt_subs(mn)}"
    return f"до {_fmt_subs(mx)}"


def _user_link(uid):
    uid = str(uid)
    if uid.isdigit():
        return f'<a href="tg://user?id={uid}">{escape_html(uid)}</a>'
    return f'<code>{escape_html(uid)}</code>'


def plan_title(plan):
    p = (plan or "free").lower()
    if p == "max":
        return "Max"
    if p == "pro":
        return "Pro"
    return "Free"


def plan_expires(u):
    exp = u.get("planExpiresAt") or u.get("proExpiresAt")
    if not exp:
        return None
    try:
        return str(exp).replace("T", " ")[:16]
    except Exception:
        return None


def _link_label(url):
    u = (url or "").strip()
    low = u.lower()
    href = u
    if low.startswith("www."):
        href = "https://" + u
    if "t.me/" in low or "telegram.me/" in low:
        return "Telegram", href
    if "instagram.com" in low:
        return "Instagram", href
    if "vk.com" in low or "vkontakte" in low:
        return "VK", href
    if "youtube.com" in low or "youtu.be" in low:
        return "YouTube", href
    if "tiktok.com" in low:
        return "TikTok", href
    if "facebook.com" in low or "fb.com" in low:
        return "Facebook", href
    if "x.com" in low or "twitter.com" in low:
        return "X", href
    if "wa.me" in low or "whatsapp.com" in low:
        return "WhatsApp", href
    if "linkedin.com" in low:
        return "LinkedIn", href
    if low.startswith("http://") or low.startswith("https://"):
        try:
            host = urllib.parse.urlparse(href).netloc.replace("www.", "")
        except Exception:
            host = "Сайт"
        host = host or "Сайт"
        if len(host) > 22:
            host = host[:21] + "…"
        return host, href
    return "Ссылка", href


def _format_labeled_links(links, max_items=6):
    parts = []
    counts = {}
    for l in links[:max_items]:
        label, href = _link_label(l)
        base = label
        counts[base] = counts.get(base, 0) + 1
        show = label if counts[base] == 1 else f"{label} {counts[base]}"
        parts.append(f'<a href="{escape_html(href)}">{escape_html(show)}</a>')
    return " · ".join(parts)


def _compact_links(c):
    url = c.get("url") or ""
    links = [l for l in (c.get("links") or []) if l and l != url]
    seen = set()
    uniq = []
    for l in links:
        if l in seen:
            continue
        seen.add(l)
        uniq.append(l)
    return uniq


def format_channel(c, idx):
    title = c.get("title") or "Без названия"
    url = c.get("url") or ""
    subs = c.get("subscribers")
    subs_s = "скр." if subs is None else f"{subs:,}".replace(",", " ")
    recent = c.get("recentVideos") or []
    last = (recent[0].get("publishedAt", "")[:10] if recent else "—") or "—"
    # status emoji
    has_desc = bool(c.get("linkInChannelDescription"))
    has_vid = bool(c.get("linkInRecentVideos"))
    if has_desc:
        status = "🟢"
    elif has_vid:
        status = "🟡"
    else:
        status = "🔴"
    channel_line = f'▶️ <a href="{escape_html(url)}">YouTube-канал</a>' if url else ""
    lines = [
        f"{status} <b>{idx}. {escape_html(title)}</b>",
        channel_line,
        f"👥 {subs_s} подписчиков · 🎬 {c.get('videoCount', 0)} видео · 📅 {last}",
    ]
    # links with sources
    ls = c.get("link_sources") or []
    if ls:
        lines.append("🔗 Найденные ссылки:")
        for item in ls[:5]:
            lines.append(f"   • <a href=\"{escape_html(item['url'])}\">{escape_html(item['url'][:60])}</a> — {escape_html(item['source'])}")
        if len(ls) > 5:
            lines.append(f"   … и ещё {len(ls)-5}")
    return "\n".join([l for l in lines if l])


def profile_text(user_id):
    s = get_settings()
    u = get_user(user_id)
    used = get_usage(user_id)
    limit = plan_limit(user_id)
    rem = max(0, limit - used)
    plan = plan_title(u.get("plan", "free"))
    exp = plan_expires(u)
    exp_line = f"\n📅 <b>До:</b> {escape_html(exp)} UTC" if (plan in ("Pro", "Max") and exp) else ""
    uname = (u.get("username") or "").strip()
    name = u.get("name") or "—"
    uid = u.get("id") or user_id
    phone = "—"
    try:
        ts = get_telegram_session(user_id)
        phone = ts.get("phone") or "—"
    except Exception:
        pass
    extra = "\n🚀 <b>Авторассылка:</b> доступна" if plan == "Max" else ""
    return (
        f"👤 <b>Профиль</b>\n\n"
        f"<blockquote>"
        f"🆔 <b>ID:</b> <code>{escape_html(str(uid))}</code>\n"
        f"👤 <b>Имя:</b> {escape_html(name)}\n"
        f"🔗 <b>Username:</b> " + (f"@{escape_html(uname)}" if uname else "—") + "\n"
        f"📱 <b>Телефон:</b> {escape_html(phone)}\n"
        f"💎 <b>Тариф:</b> {plan}{exp_line}"
        f"</blockquote>\n"
        f"📊 <b>Лимиты сегодня</b>\n"
        f"<blockquote>"
        f"Лимит: <b>{limit}</b>\n"
        f"Использовано: <b>{used}</b>\n"
        f"Осталось: <b>{rem}</b>{extra}\n"
        f"Сброс: полночь PT (квота YouTube)"
        f"</blockquote>"
    )


def plans_text():
    s = get_settings()
    return (
        "💎 <b>Тарифы ClientFy</b>\n\n"
        f"• <b>Free</b>: {int(s.get('freeLimit', 5))} каналов в день\n"
        f"• <b>Pro</b>: ${s.get('proPriceUsd', 3)} / месяц — {int(s.get('proLimit', 50))} каналов в день\n"
        f"• <b>Max</b>: ${s.get('maxPriceUsd', 6)} / месяц — {int(s.get('maxLimit', 100))} каналов в день + Авторассылка\n\n"
        "• Дневной лимит сбрасывается в полночь PT (квота YouTube)\n"
        "• Платные тарифы выдаются на 30 дней\n\n"
        f"Оплата: Visa (карта), Telegram Stars (Pro: {int(s.get('proPriceStars', 150))} ⭐, Max: {int(s.get('maxPriceStars', 300))} ⭐) или через поддержку."
    )


def pay_kb():
    s = get_settings()
    return ik([
        [{"text": f"Pro — ${s.get('proPriceUsd',3)} / {int(s.get('proLimit',50))} кан./день", "callback_data": "pay:plan:pro"}],
        [{"text": f"Max — ${s.get('maxPriceUsd',6)} / {int(s.get('maxLimit',100))} кан./день + Авторассылка", "callback_data": "pay:plan:max"}],
        [{"text": "🧾 Мои заявки", "callback_data": "menu:myapps"}],
        [{"text": "⬅️ Назад", "callback_data": "menu:home"}],
    ])


def profile_kb(user_id=None):
    rows = [[{"text": "🧾 Мои заявки", "callback_data": "menu:myapps"}]]
    rows.append([{"text": "⬅️ Назад", "callback_data": "menu:home"}])
    return ik(rows)


def search_filters_kb(state):
    days = state.get("days")
    ch = bool(state.get("require_channel_link"))
    rv = bool(state.get("require_recent_link"))
    count = int(state.get("count") or 5)
    if count < 1:
        count = 5
    if count > 15:
        count = 15
    days_label = "Любое время" if not days else f"Последние {days} дн."
    subs_label = _subs_label(state)
    lang = state.get("language") or "Любой"
    return ik([
        [{"text": f"📅 Период: {days_label}", "callback_data": "sf:days"}, {"text": f"📊 Каналов: {count}", "callback_data": "sf:count"}],
        [{"text": f"🌐 Язык: {lang}", "callback_data": "sf:langmenu"}],
        [{"text": ("✅ " if ch else "") + "Ссылка в описании канала", "callback_data": "sf:chlink"}],
        [{"text": ("✅ " if rv else "") + "Ссылка в последних 3 видео", "callback_data": "sf:rvlink"}],
        [{"text": "✍️ Ввести запрос и искать", "callback_data": "sf:query"}],
        [{"text": "⬅️ Назад", "callback_data": "menu:home"}],
    ])


def subs_kb():
    return ik([
        [{"text": "Любые", "callback_data": "subs:any"}],
        [{"text": "0 – 1K", "callback_data": "subs:0:1000"}, {"text": "1K – 10K", "callback_data": "subs:1000:10000"}],
        [{"text": "10K – 100K", "callback_data": "subs:10000:100000"}, {"text": "100K – 1M", "callback_data": "subs:100000:1000000"}],
        [{"text": "1M+", "callback_data": "subs:1000000:"}],
        [{"text": "✍️ Задать вручную (от и до)", "callback_data": "subs:custom"}],
        [{"text": "⬅️ К фильтрам", "callback_data": "menu:search"}],
    ])


def days_kb():
    return ik([
        [{"text": "Любое время", "callback_data": "days:0"}, {"text": "7 дней", "callback_data": "days:7"}],
        [{"text": "14 дней", "callback_data": "days:14"}, {"text": "30 дней", "callback_data": "days:30"}],
        [{"text": "⬅️ К фильтрам", "callback_data": "menu:search"}],
    ])


def main_menu_kb(user_id=None):
    s = get_settings()
    rows = [
        [{"text": "🔎 Поиск каналов", "callback_data": "menu:search"}],
        [{"text": "☰ История поиска", "callback_data": "menu:history"}, {"text": "⚇ Мой профиль", "callback_data": "menu:profile"}],
        [{"text": "❖ Тарифы", "callback_data": "menu:plans"}, {"text": "₽ Оплата", "callback_data": "menu:pay"}],
        [{"text": "⌘ Промокод", "callback_data": "menu:promo"}],
        [{"text": "▹ Канал бота", "url": s.get("channelUrl") or TELEGRAM_CHANNEL_URL}, {"text": "☏ Поддержка", "url": s.get("supportUrl") or SUPPORT_URL}],
    ]
    if user_id is not None:
        u = get_user(user_id)
        if (u.get("plan") or "free") == "max":
            rows.insert(1, [{"text": "✉︎ Авторассылка", "callback_data": "menu:autosend"}])
    if user_id is not None and is_owner(user_id):
        rows.insert(1, [{"text": "⚙︎ Админ-панель", "callback_data": "menu:admin"}])
    return ik(rows)


# ===== Admin =====

def _app_status_label(status):
    return {"pending": "⏳ Ожидает", "approved": "✅ Подтверждена", "rejected": "❌ Отклонена"}.get(status, status)


def _user_link_admin(uid):
    uid = str(uid)
    try:
        u = get_user(uid)
        uname = (u.get("username") or "").strip().lstrip("@")
        if uname:
            return f'<a href="https://t.me/{escape_html(uname)}">{escape_html(uname)}</a>'
    except Exception:
        pass
    if uid.isdigit():
        return f'<a href="tg://user?id={uid}">{escape_html(uid)}</a>'
    return f'<code>{escape_html(uid)}</code>'


def admin_menu_kb():
    s = get_settings()
    pending = len(list_payment_apps("pending", 100))
    apps_label = f"🧾 Заявки ({pending})" if pending else "🧾 Заявки"
    maint = "🟢 Выкл" if not s.get("maintenanceMode") else "🔴 Вкл"
    return ik([
        [{"text": apps_label, "callback_data": "adm:apps"}, {"text": "📊 Статистика", "callback_data": "adm:stats"}],
        [{"text": "👥 Пользователи", "callback_data": "adm:users"}, {"text": "🔎 Найти пользователя", "callback_data": "adm:finduser"}],
        [{"text": "🔒 Заблокировать", "callback_data": "adm:block"}, {"text": "🔓 Разблокировать", "callback_data": "adm:unblock"}],
        [{"text": "📈 Квота YouTube", "callback_data": "adm:ytquota"}, {"text": "💎 Подписки (Pro/Max)", "callback_data": "adm:sub"}],
        [{"text": "🎁 Выдать запросы", "callback_data": "adm:grantreq"}, {"text": "🔄 Сброс лимита", "callback_data": "adm:resetusage"}],
        [{"text": "🔧 Тех. работы: " + maint, "callback_data": "adm:maintenance"}],
        [{"text": "💳 Реквизиты", "callback_data": "adm:card"}, {"text": f"⭐ Pro {int(s.get('proPriceStars',150))}", "callback_data": "adm:stars:pro"}, {"text": f"⭐ Max {int(s.get('maxPriceStars',300))}", "callback_data": "adm:stars:max"}],
        [{"text": "⌘ Промокоды", "callback_data": "adm:promo"}],
        [{"text": "📢 Рассылка всем", "callback_data": "adm:broadcast"}],
        [{"text": "⬅️ В меню", "callback_data": "menu:home"}],
    ])


def admin_text():
    s = get_settings()
    maint = "🔴 ВКЛ" if s.get("maintenanceMode") else "🟢 ВЫКЛ"
    return (
        "🛠 <b>Админ-панель</b>\n\n"
        f"Реквизиты карты:\n<code>{escape_html(s.get('cardRequisites') or '—')}</code>\n\n"
        f"Pro: ${s.get('proPriceUsd', 3)} / {int(s.get('proPriceStars', 150))} ⭐ · {int(s.get('proLimit', 50))} каналов/день\n"
        f"Max: ${s.get('maxPriceUsd', 6)} / {int(s.get('maxPriceStars', 300))} ⭐ · {int(s.get('maxLimit', 100))} каналов/день + Авторассылка\n"
        f"Free: {int(s.get('freeLimit', 5))} каналов/день\n"
        f"🔧 Тех. работы: {maint}\n\n"
        "Функции: заявки, статистика, пользователи, квота YouTube, выдача запросов/подписки, промокоды, рассылка.\n"
    )


def _app_caption(app):
    uname = f"@{app.get('username')}" if app.get("username") else "—"
    created = (app.get("created_at") or "")[:19].replace("T", " ")
    apl = plan_title(app.get("plan") or "pro")
    return (
        f"🧾 <b>Заявка #{app.get('id')}</b>\n"
        f"Статус: {_app_status_label(app.get('status'))}\n"
        f"Тариф: <b>{apl}</b>\n"
        f"Пользователь: {_user_link_admin(app.get('user_id'))} ({escape_html(app.get('name') or '')} {escape_html(uname)})\n"
        f"Создана: {created}\n"
        f"Тип оплаты: {escape_html(app.get('payment_method') or 'card')}\n"
        + (f"Комментарий админа: {escape_html(app.get('admin_note') or '')}" if app.get("admin_note") else "")
    )


def _app_action_kb(app_id, status="pending"):
    if status != "pending":
        return ik([[{"text": "⬅️ К заявкам", "callback_data": "adm:apps"}]])
    app = get_payment_app(app_id) or {}
    apl = plan_title(app.get("plan") or "pro")
    return ik([
        [{"text": f"✅ Подтвердить (выдать {apl})", "callback_data": f"adm:appok:{app_id}"}],
        [{"text": "❌ Отклонить", "callback_data": f"adm:appno:{app_id}"}, {"text": "💬 Подсказать", "callback_data": f"adm:appmsg:{app_id}"}],
        [{"text": "⬅️ К заявкам", "callback_data": "adm:apps"}],
    ])


# ===== Userbot / Autoresponder =====

_USERBOT_LOCK = threading.Lock()
_MAILING_TASKS = {}


def _userbot_connect(user_id):
    """Connect userbot (Telethon) and return (client, error)."""
    sess = get_telegram_session(user_id)
    api_id = sess.get("api_id") or TELEGRAM_API_ID
    api_hash = sess.get("api_hash") or TELEGRAM_API_HASH
    blob = sess.get("session_string")
    if sess.get("needs_reauth"):
        return None, "needs_reauth"
    if not blob:
        return None, "not_authorized"
    session_string = decrypt_session(blob)
    if not session_string:
        return None, "decrypt_failed"
    try:
        from telethon.sync import TelegramClient as SyncTelegramClient
        from telethon.sessions import StringSession
        client = SyncTelegramClient(StringSession(session_string), int(api_id), api_hash)
        client.connect()
        if not client.is_user_authorized():
            client.disconnect()
            return None, "not_authorized"
        return client, None
    except Exception as e:
        return None, str(e)


def _disconnect_account(user_id):
    sess = get_telegram_session(user_id)
    blob = sess.get("session_string")
    if blob:
        try:
            session_string = decrypt_session(blob)
            from telethon.sync import TelegramClient as SyncTelegramClient
            from telethon.sessions import StringSession
            api_id = sess.get("api_id") or TELEGRAM_API_ID
            api_hash = sess.get("api_hash") or TELEGRAM_API_HASH
            client = SyncTelegramClient(StringSession(session_string), int(api_id), api_hash)
            client.connect()
            client.log_out()
            client.disconnect()
        except Exception:
            pass
    delete_telegram_session(user_id)


def _send_code_request(user_id, phone):
    """Send code request via Telethon. Returns (ok, err)."""
    api_id = TELEGRAM_API_ID
    api_hash = TELEGRAM_API_HASH
    if not api_id or not api_hash:
        return False, "API credentials not set"
    try:
        from telethon.sync import TelegramClient as SyncTelegramClient
        from telethon.sessions import StringSession
        client = SyncTelegramClient(StringSession(), int(api_id), api_hash)
        client.connect()
        sent = client.send_code_request(phone)
        with _AUTH_LOCK:
            _AUTH_CLIENTS[str(user_id)] = {"client": client, "phone": phone, "phone_code_hash": sent.phone_code_hash}
        return True, None
    except Exception as e:
        try:
            client.disconnect()
        except Exception:
            pass
        return False, str(e)


def _sign_in_userbot(user_id, code):
    """Sign in with code. Returns (ok, err). err can be PASSWORD_NEEDED."""
    with _AUTH_LOCK:
        st = _AUTH_CLIENTS.get(str(user_id))
    if not st:
        return False, "Сессия авторизации не найдена. Начните заново."
    client = st["client"]
    phone = st["phone"]
    phone_code_hash = st["phone_code_hash"]
    try:
        client.sign_in(phone, code, phone_code_hash=phone_code_hash)
    except Exception as e:
        err = str(e)
        if "password" in err.lower() or "2fa" in err.lower() or "PASSWORD" in err.upper():
            return False, "PASSWORD_NEEDED"
        return False, err
    try:
        session_string = client.session.save()
        from security import encrypt_session
        blob = encrypt_session(session_string)
        set_telegram_session(user_id, phone, blob, TELEGRAM_API_ID, TELEGRAM_API_HASH)
        client.disconnect()
        with _AUTH_LOCK:
            _AUTH_CLIENTS.pop(str(user_id), None)
        return True, None
    except Exception as e:
        return False, str(e)


def _sign_in_with_password(user_id, password):
    with _AUTH_LOCK:
        st = _AUTH_CLIENTS.get(str(user_id))
    if not st:
        return False, "Сессия авторизации не найдена. Начните заново."
    client = st["client"]
    phone = st["phone"]
    try:
        client.sign_in(password=password)
    except Exception as e:
        return False, str(e)
    try:
        session_string = client.session.save()
        from security import encrypt_session
        blob = encrypt_session(session_string)
        set_telegram_session(user_id, phone, blob, TELEGRAM_API_ID, TELEGRAM_API_HASH)
        client.disconnect()
        with _AUTH_LOCK:
            _AUTH_CLIENTS.pop(str(user_id), None)
        return True, None
    except Exception as e:
        return False, str(e)




def _codepad_kb(buf):
    rows = []
    for row in (["1","2","3"],["4","5","6"],["7","8","9"]):
        rows.append([{"text": d, "callback_data": f"codepad:d:{d}"} for d in row])
    rows.append([{"text": "0", "callback_data": "codepad:d:0"}, {"text": "⌫", "callback_data": "codepad:back"}, {"text": "✅", "callback_data": "codepad:submit"}])
    rows.append([{"text": "❌ Отмена", "callback_data": "codepad:cancel"}])
    return ik(rows)


def _masked_code(buf):
    return " ".join("•" for _ in buf) if buf else "—"



def _finalize_promo(user_id, chat_id, msg, state):
    pd = state.get("promo_data") or {}
    code = pd.get("name")
    ptype = pd.get("type")
    max_uses = int(pd.get("max_uses") or 1)
    mid = (msg or {}).get("message_id") if isinstance(msg, dict) else None
    def _send(text):
        if mid:
            edit_message(chat_id, mid, text, reply_markup=ik([{"text": "⬅️ Назад", "callback_data": "adm:promo"}]), parse_mode="HTML")
        else:
            send_message(chat_id, text, reply_markup=ik([{"text": "⬅️ Назад", "callback_data": "adm:promo"}]), parse_mode="HTML")
    if ptype == "requests":
        requests = int(pd.get("requests") or 10)
        pc = create_promo_code(code, "requests", requests=requests, max_uses=max_uses, created_by=user_id)
        if pc:
            _send(f"✅ Промокод <code>{pc['code']}</code> создан:\n+{pc['requests']} запросов, лимит {pc['max_uses']}.")
    else:
        plan = pd.get("plan") or "MAX"
        days = int(pd.get("days") or 7)
        pc = create_promo_code(code, "subscription", plan=plan, days=days, max_uses=max_uses, created_by=user_id)
        if pc:
            _send(f"✅ Промокод <code>{pc['code']}</code> создан:\n{pc['plan'].upper()} на {pc['days']} дн., лимит {pc['max_uses']}.")
    state["promo_step"] = None
    state["promo_data"] = {}
    set_bot_state(user_id, state)


def _start_mailing_task(user_id, chat_id):
    with _USERBOT_LOCK:
        if user_id in _MAILING_TASKS:
            return False, "Already running"
        _MAILING_TASKS[user_id] = {"stop": False}

    def run_mailing():
        try:
            _mailing_loop_sync(user_id, chat_id)
        finally:
            with _USERBOT_LOCK:
                _MAILING_TASKS.pop(user_id, None)

    thread = threading.Thread(target=run_mailing, daemon=True)
    thread.start()
    return True, "Started"


def _stop_mailing_task(user_id):
    with _USERBOT_LOCK:
        task = _MAILING_TASKS.get(user_id)
        if task:
            task["stop"] = True
            return True
    return False


def _mailing_loop_sync(user_id, chat_id):
    sess = get_telegram_session(user_id)
    api_id = sess.get("api_id") or TELEGRAM_API_ID
    api_hash = sess.get("api_hash") or TELEGRAM_API_HASH
    blob = sess.get("session_string")

    if sess.get("needs_reauth") or not blob:
        send_message(chat_id, "❌ Авторассылка: аккаунт не подключён. Подключите аккаунт.")
        return

    session_string = decrypt_session(blob)
    if not session_string:
        send_message(chat_id, "❌ Авторассылка: не удалось расшифровать сессию.")
        return

    cfg = get_autosend(user_id)
    template = cfg.get("template") or "Здравствуйте! Увидел ваш канал «{title}» ({url})."
    limits = cfg.get("limits") or {}
    dmin = max(5, int(limits.get("delay_seconds_min") or 20))
    dmax = max(dmin, int(limits.get("delay_seconds_max") or 30))
    max_per_run = max(1, int(limits.get("max_per_run") or 30))

    targets_data = load_json(targets_path(user_id), {"targets": []})
    targets = targets_data.get("targets") or []
    sent_data = load_json(sent_path(user_id), {"sent": []})
    sent_list = sent_data.get("sent") or []
    sent_set = {str(x.get("username", "")).lower() for x in sent_list}

    if not targets:
        send_message(chat_id, "❌ Нет получателей. Сначала соберите контакты.")
        return

    try:
        from telethon.sync import TelegramClient as SyncTelegramClient
        from telethon.sessions import StringSession
        client = SyncTelegramClient(StringSession(session_string), int(api_id), api_hash)
        client.connect()
        if not client.is_user_authorized():
            send_message(chat_id, "❌ Авторассылка: аккаунт не авторизован. Подключите аккаунт.")
            client.disconnect()
            mark_needs_reauth(user_id)
            return
    except Exception as e:
        send_message(chat_id, f"❌ Авторассылка: ошибка подключения: {e}")
        return

    sent_now = 0
    task_info = _MAILING_TASKS.get(user_id, {})

    for t in targets:
        if task_info.get("stop"):
            send_message(chat_id, "🛑 Авторассылка остановлена.")
            break
        if sent_now >= max_per_run:
            send_message(chat_id, f"⏸ Достигнут лимит за запуск: {max_per_run}")
            break
        uname = str(t.get("username") or "")
        key = uname.lower()
        if not uname or key in sent_set:
            continue
        ctx = {
            "title": t.get("source_channel") or "",
            "url": t.get("source_channel_url") or "",
            "username": uname,
            "topic": t.get("source_topic") or "",
        }
        try:
            msg_text = template.format(**ctx)
        except Exception:
            msg_text = template
            for k, v in ctx.items():
                msg_text = msg_text.replace("{" + k + "}", str(v))
        try:
            client.send_message(uname, msg_text)
            sent_list.append({"username": uname, "at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "status": "ok"})
            sent_set.add(key)
            sent_now += 1
            save_json(sent_path(user_id), {"sent": sent_list})
            send_message(chat_id, f"📤 Отправлено: @{uname} ({sent_now}/{len(targets)})")
        except Exception as e:
            err_str = str(e).lower()
            if "flood" in err_str:
                send_message(chat_id, "⏳ FloodWait — пауза 60 сек.")
                time.sleep(60)
                continue
            elif "privacy" in err_str or "restricted" in err_str:
                sent_list.append({"username": uname, "at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "status": "privacy"})
                sent_set.add(key)
                save_json(sent_path(user_id), {"sent": sent_list})
            else:
                send_message(chat_id, f"⚠️ Ошибка у @{uname}: {e}")
        time.sleep(random.randint(dmin, dmax))

    try:
        client.disconnect()
    except Exception:
        pass
    if not task_info.get("stop"):
        send_message(chat_id, f"✅ Авторассылка завершена. Отправлено: {sent_now}")

# ===== Handle Update =====

def handle_update(update):
    if "callback_query" in update:
        cq = update["callback_query"]
        data = cq.get("data") or ""
        msg = cq.get("message") or {}
        chat_id = (msg.get("chat") or {}).get("id")
        user = cq.get("from") or {}
        user_id = str(user.get("id"))
        state = get_bot_state(user_id) or {"days": 7, "count": 5, "require_channel_link": False, "require_recent_link": False}
        state.setdefault("count", 5)

        # Save user info
        try:
            name = " ".join(x for x in [(user.get("first_name") or ""), (user.get("last_name") or "")] if x).strip()
            username = (user.get("username") or "").strip()
            get_user(user_id, name=name, username=username)
        except Exception:
            pass

        # Blocked user check
        if is_blocked(user_id) and not is_owner(user_id):
            answer_callback(cq.get("id"), "⛔ Ваш аккаунт заблокирован. Свяжитесь с поддержкой.", show_alert=True)
            return

        # Maintenance mode check
        s = get_settings()
        if s.get("maintenanceMode") and not can_admin(user_id, state):
            answer_callback(cq.get("id"), "🔧 В боте ведутся технические работы. Попробуйте позже.", show_alert=True)
            return

        if data == "noop":
            answer_callback(cq.get("id"))
            return
        if data == "res:copylinks":
            st = get_bot_state(user_id) or {}
            res = st.get("last_results") or []
            links = []
            for r in res:
                for l in (r.get("links") or []):
                    if l not in links:
                        links.append(l)
                if r.get("url") and r.get("url") not in links:
                    links.append(r.get("url"))
            if not links:
                answer_callback(cq.get("id"), "Нет ссылок", show_alert=True)
                return
            text = "📋 <b>Ссылки из последнего поиска:</b>\n" + "\n".join(escape_html(l) for l in links[:100])
            send_message(chat_id, text, parse_mode="HTML")
            answer_callback(cq.get("id"))
            return

        if data.startswith("codepad:"):
            st = get_bot_state(user_id) or {}
            if st.get("auth_step") != "code":
                answer_callback(cq.get("id"), "Нет активного ввода кода", show_alert=True)
                return
            buf = st.get("code_input") or ""
            if data.startswith("codepad:d:"):
                d = data.split(":")[-1]
                if len(buf) < 8:
                    buf += d
                st["code_input"] = buf
                set_bot_state(user_id, st)
                edit_message(chat_id, msg.get("message_id"), f"Введите код: {_masked_code(buf)}", reply_markup=_codepad_kb(buf), parse_mode="HTML")
                answer_callback(cq.get("id"))
                return
            if data == "codepad:back":
                buf = buf[:-1]
                st["code_input"] = buf
                set_bot_state(user_id, st)
                edit_message(chat_id, msg.get("message_id"), f"Введите код: {_masked_code(buf)}", reply_markup=_codepad_kb(buf), parse_mode="HTML")
                answer_callback(cq.get("id"))
                return
            if data == "codepad:submit":
                if not buf:
                    answer_callback(cq.get("id"), "Код пуст", show_alert=True)
                    return
                ok, err = _sign_in_userbot(user_id, buf)
                if ok:
                    st["auth_step"] = None
                    st["code_input"] = ""
                    set_bot_state(user_id, st)
                    edit_message(chat_id, msg.get("message_id"), "✅ Авторизация успешна! Аккаунт подключен.", reply_markup=ik([{"text": "🚀 Начать рассылку", "callback_data": "autosend:start"}, {"text": "⬅️ Назад", "callback_data": "menu:autosend"}]), parse_mode="HTML")
                else:
                    if err == "PASSWORD_NEEDED":
                        st["auth_step"] = "password"
                        st["code_input"] = ""
                        set_bot_state(user_id, st)
                        edit_message(chat_id, msg.get("message_id"), "🔐 Требуется 2FA-пароль. Введите пароль:", reply_markup=ik([{"text": "⬅️ Назад", "callback_data": "menu:autosend"}]), parse_mode="HTML")
                    else:
                        st["code_input"] = ""
                        set_bot_state(user_id, st)
                        edit_message(chat_id, msg.get("message_id"), f"❌ Ошибка: {err}\nПопробуйте снова.", reply_markup=_codepad_kb(""))
                        send_message(chat_id, "Введите код кнопками ниже.")
                answer_callback(cq.get("id"))
                return
            if data == "codepad:cancel":
                st["auth_step"] = None
                st["code_input"] = ""
                set_bot_state(user_id, st)
                edit_message(chat_id, msg.get("message_id"), "Отменено.", reply_markup=ik([{"text": "⬅️ Назад", "callback_data": "menu:autosend"}]), parse_mode="HTML")
                answer_callback(cq.get("id"))
                return

        if data == "menu:promo":
            clear_transient(state)
            set_bot_state(user_id, state)
            edit_message(chat_id, msg.get("message_id"), "🎟 Отправьте промокод (например: SALE10):", reply_markup=ik([{"text": "⬅️ Назад", "callback_data": "menu:home"}]), parse_mode="HTML")
            state["awaiting_promo_redeem"] = True
            set_bot_state(user_id, state)
            answer_callback(cq.get("id"))
            return

        if data == "check_sub":
            if check_subscription(user_id):
                clear_transient(state)
                set_bot_state(user_id, state)
                edit_message(chat_id, msg.get("message_id"), "🏠 <b>Главное меню</b>", reply_markup=main_menu_kb(user_id), parse_mode="HTML")
                answer_callback(cq.get("id"), "✅ Подписка подтверждена")
            else:
                edit_message(chat_id, msg.get("message_id"), "❌ Вы не подписаны на канал.\nПодпишитесь и нажмите «Проверить».", reply_markup=subscription_prompt_kb(), parse_mode="HTML")
                answer_callback(cq.get("id"), "Подписка не найдена", show_alert=True)
            return

        if data == "menu:home":
            keep = {}
            if is_owner(user_id):
                keep["is_admin"] = True
            set_bot_state(user_id, keep)
            edit_message(chat_id, msg.get("message_id"), "🏠 <b>Главное меню</b>", reply_markup=main_menu_kb(user_id), parse_mode="HTML")
            answer_callback(cq.get("id"))
            return

        if data == "menu:admin":
            if not can_admin(user_id, state):
                answer_callback(cq.get("id"), "Нет доступа", show_alert=True)
                return
            clear_transient(state)
            state["is_admin"] = True
            set_bot_state(user_id, state)
            edit_message(chat_id, msg.get("message_id"), admin_text(), reply_markup=admin_menu_kb(), parse_mode="HTML")
            answer_callback(cq.get("id"))
            return

        if data == "menu:search":
            clear_transient(state)
            set_bot_state(user_id, state)
            edit_message(chat_id, msg.get("message_id"), "🔎 <b>Поиск каналов</b>\n\nНастройте фильтры, затем введите запрос:", reply_markup=search_filters_kb(state), parse_mode="HTML")
            answer_callback(cq.get("id"))
            return

        if data == "menu:plans":
            clear_transient(state)
            set_bot_state(user_id, state)
            edit_message(chat_id, msg.get("message_id"), plans_text(), reply_markup=ik([[{"text": "₽ Оплата", "callback_data": "menu:pay"}], [{"text": "⬅️ Назад", "callback_data": "menu:home"}]]), parse_mode="HTML")
            answer_callback(cq.get("id"))
            return

        if data == "menu:profile":
            clear_transient(state)
            set_bot_state(user_id, state)
            edit_message(chat_id, msg.get("message_id"), profile_text(user_id), reply_markup=profile_kb(user_id), parse_mode="HTML")
            answer_callback(cq.get("id"))
            return

        if data == "menu:pay":
            clear_transient(state)
            set_bot_state(user_id, state)
            edit_message(chat_id, msg.get("message_id"), "💳 <b>Оплата тарифов</b>\n\nСначала выберите тариф:", reply_markup=pay_kb(), parse_mode="HTML")
            answer_callback(cq.get("id"))
            return

        if data == "menu:history":
            clear_transient(state)
            set_bot_state(user_id, state)
            edit_message(chat_id, msg.get("message_id"), "📜 <b>История поиска</b>\nВыберите группировку:", reply_markup=ik([[{"text": "📅 По дате", "callback_data": "hist:bydate"}, {"text": "🏷 По теме", "callback_data": "hist:bytopic"}], [{"text": "⬅️ Назад", "callback_data": "menu:home"}]]), parse_mode="HTML")
            answer_callback(cq.get("id"))
            return

        if data == "menu:myapps":
            clear_transient(state)
            set_bot_state(user_id, state)
            apps = list_user_payment_apps(user_id, 10)
            if not apps:
                edit_message(chat_id, msg.get("message_id"), "🧾 У вас пока нет заявок на оплату.", reply_markup=ik([{"text": "💳 К оплате", "callback_data": "menu:pay"}, {"text": "⬅️ Назад", "callback_data": "menu:home"}]))
            else:
                lines = ["🧾 <b>Мои заявки на оплату</b>\n"]
                for a in apps:
                    created = (a.get("created_at") or "")[:16].replace("T", " ")
                    lines.append(f"#{a.get('id')} · {_app_status_label(a.get('status'))} · {created}")
                    if a.get("admin_note"):
                        lines.append(f"   💬 {escape_html((a.get('admin_note') or '')[:120])}")
                edit_message(chat_id, msg.get("message_id"), "\n".join(lines), reply_markup=ik([{"text": "🔄 Обновить", "callback_data": "menu:myapps"}, {"text": "💳 К оплате", "callback_data": "menu:pay"}, {"text": "⬅️ Назад", "callback_data": "menu:home"}]), parse_mode="HTML")
            answer_callback(cq.get("id"))
            return

        if data == "menu:autosend":
            clear_transient(state)
            set_bot_state(user_id, state)
            u = get_user(user_id)
            if (u.get("plan") or "free") != "max":
                edit_message(chat_id, msg.get("message_id"), "Авторассылка доступна только по тарифу Max.", reply_markup=profile_kb(user_id))
                answer_callback(cq.get("id"))
                return
            cfg = get_autosend(user_id)
            sess = get_telegram_session(user_id)
            has_session = bool(sess.get("session_string")) and not sess.get("needs_reauth")
            needs_reauth = bool(sess.get("needs_reauth"))
            phone = sess.get("phone") or ""
            tmpl = cfg.get("template") or ""
            if has_session:
                status = "✅ Подключён" + (f" ({phone})" if phone else "")
            elif needs_reauth:
                status = "⚠️ Требуется повторное подключение"
            else:
                status = "❌ Не подключен"
            targets = load_json(targets_path(user_id), {"targets": []}).get("targets") or []
            lines = [
                "📨 <b>Авторассылка (Max)</b>\n",
                f"📊 <b>Статус аккаунта:</b> {status}",
                f"👥 <b>Контактов:</b> <code>{len(targets)}</code>",
                f"📝 <b>Шаблон:</b>",
                f"<blockquote>{escape_html(tmpl) if tmpl else '<i>не задан</i>'}</blockquote>",
            ]
            rows = [
                [{"text": "🔐 Аккаунт", "callback_data": "autosend:sec:account"}],
                [{"text": "📋 Контакты", "callback_data": "autosend:sec:contacts"}],
                [{"text": "✏️ Текст", "callback_data": "autosend:sec:text"}],
                [{"text": "🚀 Запуск", "callback_data": "autosend:sec:start"}],
                [{"text": "⬅️ Назад", "callback_data": "menu:home"}],
            ]
            # show contacts count in status
            edit_message(chat_id, msg.get("message_id"), "\n".join(lines), reply_markup=ik(rows), parse_mode="HTML")
            answer_callback(cq.get("id"))
            return

        # Search filters
        if data == "sf:days":
            edit_message(chat_id, msg.get("message_id"), "Выберите период активности:", reply_markup=days_kb())
            answer_callback(cq.get("id"))
            return

        if data.startswith("days:"):
            val = int(data.split(":")[1])
            state["days"] = None if val == 0 else val
            set_bot_state(user_id, state)
            edit_message(chat_id, msg.get("message_id"), "🔎 <b>Поиск каналов</b>\n\nНастройте фильтры, затем введите запрос:", reply_markup=search_filters_kb(state), parse_mode="HTML")
            answer_callback(cq.get("id"), f"Период: {'любое время' if val==0 else str(val)+' дн.'}")
            return

        if data == "sf:count":
            cur = int(state.get("count") or 5)
            opts = [5, 10, 15]
            try:
                idx = opts.index(cur)
                cur = opts[(idx + 1) % len(opts)]
            except ValueError:
                cur = 5
            state["count"] = cur
            set_bot_state(user_id, state)
            edit_message(chat_id, msg.get("message_id"), "🔎 <b>Поиск каналов</b>\n\nНастройте фильтры, затем введите запрос:", reply_markup=search_filters_kb(state), parse_mode="HTML")
            answer_callback(cq.get("id"), f"Каналов: {cur}")
            return

        if data == "sf:subs":
            edit_message(chat_id, msg.get("message_id"), "👥 Выберите диапазон подписчиков:", reply_markup=subs_kb())
            answer_callback(cq.get("id"))
            return

        if data == "subs:any":
            state["subs_min"] = None
            state["subs_max"] = None
            set_bot_state(user_id, state)
            edit_message(chat_id, msg.get("message_id"), "🔎 <b>Поиск каналов</b>\n\nНастройте фильтры, затем введите запрос:", reply_markup=search_filters_kb(state), parse_mode="HTML")
            answer_callback(cq.get("id"), "Подписчики: любые")
            return

        if data.startswith("subs:") and data not in ("subs:custom",):
            parts = data.split(":")
            if len(parts) == 3:
                mn = parts[1]
                mx = parts[2]
                state["subs_min"] = int(mn) if mn != "" else None
                state["subs_max"] = int(mx) if mx != "" else None
                set_bot_state(user_id, state)
                edit_message(chat_id, msg.get("message_id"), "🔎 <b>Поиск каналов</b>\n\nНастройте фильтры, затем введите запрос:", reply_markup=search_filters_kb(state), parse_mode="HTML")
                answer_callback(cq.get("id"), "Фильтр подписчиков задан")
                return

        if data == "subs:custom":
            clear_transient(state)
            state["awaiting_subs_range"] = True
            set_bot_state(user_id, state)
            edit_message(chat_id, msg.get("message_id"), "✍️ Отправьте диапазон подписчиков в формате: <code>от до</code>\nПримеры: <code>1000 50000</code>, <code>0 1000</code>, <code>100000 0</code> (0 = без верхней границы).\nМожно одним числом: <code>5000</code> (от 5000 и выше).", reply_markup=ik([{"text": "⬅️ К фильтрам", "callback_data": "menu:search"}]), parse_mode="HTML")
            answer_callback(cq.get("id"))
            return

        if data == "sf:chlink":
            state["require_channel_link"] = not bool(state.get("require_channel_link"))
            set_bot_state(user_id, state)
            edit_message(chat_id, msg.get("message_id"), "🔎 <b>Поиск каналов</b>\n\nНастройте фильтры, затем введите запрос:", reply_markup=search_filters_kb(state), parse_mode="HTML")
            answer_callback(cq.get("id"))
            return

        if data == "sf:langmenu":
            langs = ["Любой", "Русский", "Английский", "Узбекский", "Турецкий", "Испанский", "Немецкий", "Французский", "Арабский", "Китайский"]
            rows = []
            for lg in langs:
                mark = "✅ " if (state.get("language") or "Любой") == lg else ""
                rows.append([{"text": f"{mark}{lg}", "callback_data": f"sf:setlang:{lg}"}])
            rows.append([{"text": "⬅️ К фильтрам", "callback_data": "menu:search"}])
            edit_message(chat_id, msg.get("message_id"), "🌐 Выберите язык канала:", reply_markup=ik(rows), parse_mode="HTML")
            answer_callback(cq.get("id"))
            return

        if data.startswith("sf:setlang:"):
            lang = data.split(":", 2)[-1]
            state["language"] = lang
            set_bot_state(user_id, state)
            edit_message(chat_id, msg.get("message_id"), "🔎 <b>Поиск каналов</b>\n\nНастройте фильтры, затем введите запрос:", reply_markup=search_filters_kb(state), parse_mode="HTML")
            answer_callback(cq.get("id"), f"Язык: {lang}")
            return

        if data == "sf:rvlink":
            state["require_recent_link"] = not bool(state.get("require_recent_link"))
            set_bot_state(user_id, state)
            edit_message(chat_id, msg.get("message_id"), "🔎 <b>Поиск каналов</b>\n\nНастройте фильтры, затем введите запрос:", reply_markup=search_filters_kb(state), parse_mode="HTML")
            answer_callback(cq.get("id"))
            return

        if data == "sf:query":
            clear_transient(state)
            state["awaiting_query"] = True
            set_bot_state(user_id, state)
            edit_message(chat_id, msg.get("message_id"), "✍️ Отправьте поисковый запрос одним сообщением (например: <i>маркетинг</i>, <i>крипто</i>, <i>ремонт авто</i>).", reply_markup=ik([{"text": "⬅️ К фильтрам", "callback_data": "menu:search"}]), parse_mode="HTML")
            answer_callback(cq.get("id"))
            return

        # Autoresponder callbacks
        if data == "autosend:settemplate":
            if (get_user(user_id).get("plan") or "free") != "max":
                answer_callback(cq.get("id"), "Только для тарифа Max", show_alert=True)
                return
            clear_transient(state)
            state["awaiting_autosend_template"] = True
            set_bot_state(user_id, state)
            cfg = get_autosend(user_id)
            edit_message(chat_id, msg.get("message_id"), f"Текущий шаблон:\n{cfg.get('template') or '—'}\n\nОтправьте новый текст шаблона. Доступные подстановки: {{title}}, {{url}}, {{username}}, {{topic}}.", reply_markup=ik([{"text": "⬅️ Назад", "callback_data": "menu:autosend"}]))
            answer_callback(cq.get("id"))
            return

        if data == "autosend:addcontacts":
            if (get_user(user_id).get("plan") or "free") != "max":
                answer_callback(cq.get("id"), "Только для тарифа Max", show_alert=True)
                return
            clear_transient(state)
            state["awaiting_autosend_contacts"] = True
            set_bot_state(user_id, state)
            edit_message(chat_id, msg.get("message_id"),
                "➕ <b>Добавление контактов</b>\n\n"
                "Отправьте список @username (через запятую или с новой строки).\n"
                "Пример:\n@user1, @user2\n@user3",
                reply_markup=ik([{"text": "⬅️ Назад", "callback_data": "menu:autosend"}]), parse_mode="HTML")
            answer_callback(cq.get("id"))
            return

        if data == "autosend:listcontacts":
            if (get_user(user_id).get("plan") or "free") != "max":
                answer_callback(cq.get("id"), "Только для тарифа Max", show_alert=True)
                return
            targets = load_json(targets_path(user_id), {"targets": []}).get("targets") or []
            if not targets:
                edit_message(chat_id, msg.get("message_id"), "📋 Контактов пока нет.", reply_markup=ik([{"text": "⬅️ Назад", "callback_data": "menu:autosend"}]), parse_mode="HTML")
                answer_callback(cq.get("id"))
                return
            lines = [f"📋 <b>Контакты ({len(targets)})</b>\n"]
            for t in targets[:30]:
                lines.append(f"• @{t.get('username')}")
            if len(targets) > 30:
                lines.append(f"... и ещё {len(targets)-30}")
            edit_message(chat_id, msg.get("message_id"), "\n".join(lines), reply_markup=ik([{"text": "⬅️ Назад", "callback_data": "menu:autosend"}]), parse_mode="HTML")
            answer_callback(cq.get("id"))
            return

        if data == "autosend:clearcontacts":
            if (get_user(user_id).get("plan") or "free") != "max":
                answer_callback(cq.get("id"), "Только для тарифа Max", show_alert=True)
                return
            save_json(targets_path(user_id), {"targets": []})
            edit_message(chat_id, msg.get("message_id"), "🗑 Контакты очищены.", reply_markup=ik([{"text": "⬅️ Назад", "callback_data": "menu:autosend"}]), parse_mode="HTML")
            answer_callback(cq.get("id"))
            return

        if data == "autosend:fromsearch":
            if (get_user(user_id).get("plan") or "free") != "max":
                answer_callback(cq.get("id"), "Только для тарифа Max", show_alert=True)
                return
            hist = get_history(user_id, 10)
            if not hist:
                edit_message(chat_id, msg.get("message_id"), "Нет сохранённых поисков. Сначала выполните поиск каналов.", reply_markup=ik([{"text": "⬅️ Назад", "callback_data": "menu:autosend"}]), parse_mode="HTML")
                answer_callback(cq.get("id"))
                return
            rows = []
            for i, h in enumerate(hist):
                q = (h.get("query") or "")[:30]
                cnt = h.get("count", 0)
                at = (h.get("at") or "")[:10]
                rows.append([{"text": f"🔎 {q} ({cnt}) · {at}", "callback_data": f"autosend:search:{i}"}])
            rows.append([{"text": "⬅️ Назад", "callback_data": "menu:autosend"}])
            edit_message(chat_id, msg.get("message_id"), "Выберите поиск для рассылки:", reply_markup=ik(rows), parse_mode="HTML")
            answer_callback(cq.get("id"))
            return

        if data.startswith("autosend:search:"):
            if (get_user(user_id).get("plan") or "free") != "max":
                answer_callback(cq.get("id"), "Только для тарифа Max", show_alert=True)
                return
            idx = int(data.split(":")[-1])
            hist = get_history(user_id, 10)
            if idx >= len(hist):
                answer_callback(cq.get("id"), "Поиск не найден", show_alert=True)
                return
            h = hist[idx]
            query = h.get("query") or ""
            results = h.get("results") or []
            # extract telegram usernames from links
            import re as _re
            usernames = []
            seen = set()
            for r in results:
                for link in (r.get("links") or []):
                    m = _re.search(r"t(?:elegram)?\.me/([A-Za-z0-9_]{5,})", link)
                    if m:
                        u = m.group(1)
                        if u.lower() not in seen:
                            seen.add(u.lower())
                            usernames.append(u)
            # save as targets
            data = load_json(targets_path(user_id), {"targets": []})
            targets = data.get("targets") or []
            existing = {str(t.get("username","")).lower() for t in targets}
            added = 0
            for u in usernames:
                if u.lower() in existing:
                    continue
                targets.append({"username": u, "source_channel": (r.get("title") or ""), "source_topic": query, "source_channel_url": (r.get("url") or "")})
                existing.add(u.lower())
                added += 1
            save_json(targets_path(user_id), {"targets": targets})
            # start mailing
            ok, msg_text = _start_mailing_task(user_id, chat_id)
            edit_message(chat_id, msg.get("message_id"),
                f"📨 Запущена рассылка по поиску «{query}»\nНайдено Telegram-контактов: {len(usernames)} (добавлено {added}). Всего целей: {len(targets)}.",
                reply_markup=ik([{"text": "⏹ Остановить", "callback_data": "autosend:stop"}, {"text": "⬅️ Назад", "callback_data": "menu:autosend"}]), parse_mode="HTML")
            answer_callback(cq.get("id"))
            return

        if data == "hist:bydate" or data == "hist:bytopic":
            clear_transient(state)
            set_bot_state(user_id, state)
            hist = get_history(user_id, 50)
            if not hist:
                edit_message(chat_id, msg.get("message_id"), "📜 История пуста.", reply_markup=ik([{"text": "⬅️ Назад", "callback_data": "menu:home"}]), parse_mode="HTML")
                answer_callback(cq.get("id"))
                return
            if data == "hist:bydate":
                # group by date
                from collections import defaultdict
                groups = defaultdict(list)
                for h in hist:
                    d = (h.get("at") or "")[:10]
                    groups[d].append(h)
                lines = ["📜 <b>История по датам</b>\n"]
                for d in sorted(groups.keys(), reverse=True)[:10]:
                    items = groups[d]
                    lines.append(f"📅 {d} — {len(items)} поисков")
                    for h in items[:5]:
                        lines.append(f"   • {escape_html((h.get('query') or '')[:40])} ({h.get('count',0)})")
                edit_message(chat_id, msg.get("message_id"), "\n".join(lines), reply_markup=ik([{"text": "⬅️ Назад", "callback_data": "menu:home"}]), parse_mode="HTML")
            else:
                # group by query/topic
                from collections import defaultdict
                groups = defaultdict(list)
                for h in hist:
                    q = (h.get("query") or "").strip().lower()
                    groups[q].append(h)
                lines = ["📜 <b>История по темам</b>\n"]
                for q, items in list(groups.items())[:10]:
                    lines.append(f"🏷 {escape_html(q[:40])} — {len(items)} раз(а), последний {items[0].get('count',0)} каналов")
                edit_message(chat_id, msg.get("message_id"), "\n".join(lines), reply_markup=ik([{"text": "⬅️ Назад", "callback_data": "menu:home"}]), parse_mode="HTML")
            answer_callback(cq.get("id"))
            return

        if data == "autosend:sec:account":
            if (get_user(user_id).get("plan") or "free") != "max":
                answer_callback(cq.get("id"), "Только для тарифа Max", show_alert=True)
                return
            sess = get_telegram_session(user_id)
            has_session = bool(sess.get("session_string")) and not sess.get("needs_reauth")
            needs_reauth = bool(sess.get("needs_reauth"))
            rows = []
            rows.append([{"text": "🔐 Подключить аккаунт", "callback_data": "autosend:connect"}])
            if has_session:
                rows.append([{"text": "🔌 Отключить аккаунт", "callback_data": "autosend:disconnect"}])
            if needs_reauth:
                rows.append([{"text": "🔄 Повторная авторизация", "callback_data": "autosend:reauth"}])
            rows.append([{"text": "⬅️ Назад к авторассылке", "callback_data": "menu:autosend"}])
            edit_message(chat_id, msg.get("message_id"), "🔐 <b>Аккаунт</b>", reply_markup=ik(rows), parse_mode="HTML")
            answer_callback(cq.get("id"))
            return

        if data == "autosend:sec:contacts":
            if (get_user(user_id).get("plan") or "free") != "max":
                answer_callback(cq.get("id"), "Только для тарифа Max", show_alert=True)
                return
            rows = [
                [{"text": "➕ Задать свои контакты", "callback_data": "autosend:addcontacts"}],
                [{"text": "📋 Список контактов", "callback_data": "autosend:listcontacts"}],
                [{"text": "🗑 Очистить контакты", "callback_data": "autosend:clearcontacts"}],
                [{"text": "🔎 Рассылка по поиску", "callback_data": "autosend:fromsearch"}],
                [{"text": "⬅️ Назад к авторассылке", "callback_data": "menu:autosend"}],
            ]
            edit_message(chat_id, msg.get("message_id"), "📋 <b>Контакты</b>", reply_markup=ik(rows), parse_mode="HTML")
            answer_callback(cq.get("id"))
            return

        if data == "autosend:sec:text":
            if (get_user(user_id).get("plan") or "free") != "max":
                answer_callback(cq.get("id"), "Только для тарифа Max", show_alert=True)
                return
            rows = [
                [{"text": "✏️ Шаблон сообщения", "callback_data": "autosend:settemplate"}],
                [{"text": "⬅️ Назад к авторассылке", "callback_data": "menu:autosend"}],
            ]
            edit_message(chat_id, msg.get("message_id"), "✏️ <b>Текст</b>", reply_markup=ik(rows), parse_mode="HTML")
            answer_callback(cq.get("id"))
            return

        if data == "autosend:sec:start":
            if (get_user(user_id).get("plan") or "free") != "max":
                answer_callback(cq.get("id"), "Только для тарифа Max", show_alert=True)
                return
            rows = [
                [{"text": "🚀 Начать рассылку", "callback_data": "autosend:start"}],
                [{"text": "⏹ Остановить рассылку", "callback_data": "autosend:stop"}],
                [{"text": "⬅️ Назад к авторассылке", "callback_data": "menu:autosend"}],
            ]
            edit_message(chat_id, msg.get("message_id"), "🚀 <b>Запуск</b>", reply_markup=ik(rows), parse_mode="HTML")
            answer_callback(cq.get("id"))
            return

        if data == "autosend:connect":
            if (get_user(user_id).get("plan") or "free") != "max":
                answer_callback(cq.get("id"), "Только для тарифа Max", show_alert=True)
                return
            clear_transient(state)
            state["auth_step"] = "phone"
            set_bot_state(user_id, state)
            edit_message(chat_id, msg.get("message_id"),
                "🔐 <b>Подключение аккаунта</b>\n\n"
                "Отправьте свой номер телефона — кнопкой ниже или текстом (например +79991234567).",
                reply_markup=ik([{"text": "⬅️ Назад", "callback_data": "menu:autosend"}]),
                parse_mode="HTML")
            send_message(chat_id, "👇 Нажмите кнопку:", reply_markup={"keyboard": [[{"text": "📱 Отправить контакт", "request_contact": True}]], "resize_keyboard": True, "one_time_keyboard": True})
            answer_callback(cq.get("id"))
            return

        if data == "autosend:disconnect":
            if (get_user(user_id).get("plan") or "free") != "max":
                answer_callback(cq.get("id"), "Только для тарифа Max", show_alert=True)
                return
            _disconnect_account(user_id)
            edit_message(chat_id, msg.get("message_id"), "🔌 Аккаунт отключён. Сессия удалена.", reply_markup=ik([{"text": "⬅️ Назад", "callback_data": "menu:autosend"}]), parse_mode="HTML")
            answer_callback(cq.get("id"))
            return

        if data == "autosend:reauth":
            if (get_user(user_id).get("plan") or "free") != "max":
                answer_callback(cq.get("id"), "Только для тарифа Max", show_alert=True)
                return
            mark_needs_reauth(user_id)
            clear_transient(state)
            state["auth_step"] = "phone"
            set_bot_state(user_id, state)
            edit_message(chat_id, msg.get("message_id"),
                "🔄 <b>Повторная авторизация</b>\n\nОтправьте свой номер телефона — кнопкой ниже или текстом.",
                reply_markup=ik([{"text": "⬅️ Назад", "callback_data": "menu:autosend"}]),
                parse_mode="HTML")
            send_message(chat_id, "👇 Нажмите кнопку:", reply_markup={"keyboard": [[{"text": "📱 Отправить контакт", "request_contact": True}]], "resize_keyboard": True, "one_time_keyboard": True})
            answer_callback(cq.get("id"))
            return

        if data == "autosend:info":
            info = (
                "📋 <b>Запуск авторассылки</b>\n\n"
                "1. Настройте темы (кнопка «✏️ Темы поиска») и шаблон («✏️ Шаблон сообщения»).\n"
                "2. Нажмите «🔐 Подключить аккаунт» и откройте форму авторизации.\n"
                "3. Введите номер телефона, код из Telegram и пароль 2FA (если включён).\n"
                "4. Коды и пароли вводятся только в форме, не в чате.\n"
                "5. После подключения нажмите «🚀 Начать рассылку».\n"
                "6. Для остановки — «⏹ Остановить рассылку».\n\n"
                "⚠️ Рассылка идёт от вашего личного аккаунта.\n"
                "Соблюдайте лимиты Telegram, не спамьте — аккаунт могут ограничить.\n"
                "Задержка между сообщениями: 20–30 секунд."
            )
            edit_message(chat_id, msg.get("message_id"), info, reply_markup=ik([{"text": "⬅️ Назад", "callback_data": "menu:autosend"}]), parse_mode="HTML")
            answer_callback(cq.get("id"))
            return

        if data == "autosend:start":
            if (get_user(user_id).get("plan") or "free") != "max":
                answer_callback(cq.get("id"), "Только для тарифа Max", show_alert=True)
                return
            ok, msg_text = _start_mailing_task(user_id, chat_id)
            if ok:
                answer_callback(cq.get("id"), "Рассылка запущена")
            else:
                answer_callback(cq.get("id"), msg_text, show_alert=True)
            return

        if data == "autosend:stop":
            if _stop_mailing_task(user_id):
                answer_callback(cq.get("id"), "Остановлено")
            else:
                answer_callback(cq.get("id"), "Не запущено", show_alert=True)
            return

        # Payment callbacks
        if data == "pay:card":
            clear_transient(state)
            set_bot_state(user_id, state)
            edit_message(chat_id, msg.get("message_id"), "💳 <b>Оплата картой Visa</b>\nВыберите тариф:", reply_markup=ik([{"text": "Pro (50 каналов/день)", "callback_data": "pay:card:pro"}, {"text": "Max (100 каналов/день + Авторассылка)", "callback_data": "pay:card:max"}, {"text": "⬅️ Назад", "callback_data": "menu:pay"}]), parse_mode="HTML")
            answer_callback(cq.get("id"))
            return

        if data in ("pay:card:pro", "pay:card:max"):
            plan = "max" if data.endswith(":max") else "pro"
            s = get_settings()
            title = plan_title(plan)
            price = s.get('maxPriceUsd', 6) if plan == "max" else s.get('proPriceUsd', 3)
            limit = int(s.get('maxLimit', 100) if plan == "max" else s.get('proLimit', 50))
            extra = " + Авторассылка" if plan == "max" else ""
            text = (
                f"💳 <b>Оплата на карту Visa — {title}</b>\n\n"
                f"Сумма: <b>${price}</b> за {title} (на 1 месяц)\n"
                f"Лимит: {limit} каналов/день{extra}\n\n"
                f"Реквизиты:\n<code>{escape_html(s.get('cardRequisites') or '—')}</code>\n\n"
                "После оплаты нажмите «📤 Отправить скриншот» и пришлите чек/скриншот прямо в бот — заявка уйдёт администратору."
            )
            clear_transient(state)
            state["payment_plan"] = plan
            set_bot_state(user_id, state)
            edit_message(chat_id, msg.get("message_id"), text, reply_markup=ik([{"text": f"📤 Отправить скриншот ({title})", "callback_data": "pay:proof"}, {"text": "☏ Поддержка", "url": s.get("supportUrl") or SUPPORT_URL}, {"text": "⬅️ Назад", "callback_data": "pay:card"}]), parse_mode="HTML")
            answer_callback(cq.get("id"))
            return

        if data == "pay:proof":
            plan = state.get("payment_plan") or "pro"
            if plan not in ("pro", "max"):
                plan = "pro"
            clear_transient(state)
            state["awaiting_payment_proof"] = True
            state["payment_plan"] = plan
            set_bot_state(user_id, state)
            edit_message(chat_id, msg.get("message_id"), f"📤 Отправьте скриншот/фото чека оплаты за <b>{plan_title(plan)}</b> одним сообщением (фото или документ).", reply_markup=ik([{"text": "Отмена", "callback_data": "menu:pay"}]), parse_mode="HTML")
            answer_callback(cq.get("id"))
            return

        if data == "pay:crypto":
            clear_transient(state)
            set_bot_state(user_id, state)
            edit_message(chat_id, msg.get("message_id"), "💸 <b>Оплата криптовалютой</b>\nВыберите монету:", reply_markup=ik([{"text": "GRAM", "callback_data": "pay:crypto:gram"}, {"text": "USDT TON", "callback_data": "pay:crypto:usdt"}, {"text": "⬅️ Назад", "callback_data": "menu:pay"}]), parse_mode="HTML")
            answer_callback(cq.get("id"))
            return

        if data in ("pay:crypto:gram", "pay:crypto:usdt"):
            coin = "GRAM" if data.endswith(":gram") else "USDT TON"
            clear_transient(state)
            state["payment_coin"] = coin
            state["payment_plan"] = "max"
            set_bot_state(user_id, state)
            addr = "UQAdj3eGW_V924Ch3pxMGSYNf_TgoyCtkZl-FmtrB4hSK0Bf"
            text = (
                f"💸 <b>Оплата {coin}</b>\n\n"
                f"Адрес (TON):\n<code>{addr}</code>\n\n"
                "После отправки средств нажмите «📤 Отправить скриншот» и пришлите чек/скриншот прямо в бот — заявка уйдёт администратору."
            )
            edit_message(chat_id, msg.get("message_id"), text, reply_markup=ik([{"text": "📤 Отправить скриншот", "callback_data": "pay:proof:crypto"}, {"text": "⬅️ Назад", "callback_data": "pay:crypto"}]), parse_mode="HTML")
            answer_callback(cq.get("id"))
            return

        if data == "pay:proof:crypto":
            plan = state.get("payment_plan") or "max"
            if plan not in ("pro", "max"):
                plan = "max"
            clear_transient(state)
            state["awaiting_payment_proof"] = True
            state["payment_plan"] = plan
            state["payment_coin"] = state.get("payment_coin") or "GRAM"
            set_bot_state(user_id, state)
            edit_message(chat_id, msg.get("message_id"), f"📤 Отправьте скриншот/фото чека оплаты {state.get('payment_coin')} за <b>{plan_title(plan)}</b> одним сообщением (фото или документ).", reply_markup=ik([{"text": "Отмена", "callback_data": "menu:pay"}]), parse_mode="HTML")
            answer_callback(cq.get("id"))
            return

        if data.startswith("pay:plan:"):
            plan = "max" if data.endswith(":max") else "pro"
            s = get_settings()
            title = plan_title(plan)
            price = s.get('maxPriceUsd', 6) if plan == "max" else s.get('proPriceUsd', 3)
            stars = s.get('maxPriceStars', 300) if plan == "max" else s.get('proPriceStars', 150)
            clear_transient(state)
            state["payment_plan"] = plan
            set_bot_state(user_id, state)
            text = (
                f"💳 <b>Оплата — {title}</b>\n\n"
                f"Сумма: <b>${price}</b> / <b>{stars} ⭐</b> за {title} (на 1 месяц)\n\n"
                "Выберите способ оплаты:"
            )
            edit_message(chat_id, msg.get("message_id"), text, reply_markup=ik([
                [{"text": f"⭐ Stars ({stars} ⭐)", "callback_data": f"pay:stars:{plan}"}],
                [{"text": "💳 Карта Visa", "callback_data": "pay:card:plan"}],
                [{"text": "💸 GRAM", "callback_data": "pay:crypto:gram"}],
                [{"text": "💸 USDT TON", "callback_data": "pay:crypto:usdt"}],
                [{"text": "⬅️ Назад", "callback_data": "menu:pay"}],
            ]), parse_mode="HTML")
            answer_callback(cq.get("id"))
            return

        if data == "pay:card:plan":
            plan = state.get("payment_plan") or "pro"
            s = get_settings()
            title = plan_title(plan)
            price = s.get('maxPriceUsd', 6) if plan == "max" else s.get('proPriceUsd', 3)
            limit = int(s.get('maxLimit', 100) if plan == "max" else s.get('proLimit', 50))
            extra = " + Авторассылка" if plan == "max" else ""
            text = (
                f"💳 <b>Оплата на карту Visa — {title}</b>\n\n"
                f"Сумма: <b>${price}</b> за {title} (на 1 месяц)\n"
                f"Лимит: {limit} каналов/день{extra}\n\n"
                f"Реквизиты:\n<code>{escape_html(s.get('cardRequisites') or '—')}</code>\n\n"
                "После оплаты нажмите «📤 Отправить скриншот»."
            )
            clear_transient(state)
            state["payment_plan"] = plan
            set_bot_state(user_id, state)
            edit_message(chat_id, msg.get("message_id"), text, reply_markup=ik([{"text": f"📤 Отправить скриншот ({title})", "callback_data": "pay:proof"}, {"text": "☏ Поддержка", "url": s.get("supportUrl") or SUPPORT_URL}, {"text": "⬅️ Назад", "callback_data": "pay:plan:" + plan}]), parse_mode="HTML")
            answer_callback(cq.get("id"))
            return

        # route crypto through selected plan
        if data in ("pay:crypto:gram", "pay:crypto:usdt"):
            coin = "GRAM" if data.endswith(":gram") else "USDT TON"
            plan = state.get("payment_plan") or "pro"
            clear_transient(state)
            state["payment_coin"] = coin
            state["payment_plan"] = plan
            set_bot_state(user_id, state)
            addr = "UQAdj3eGW_V924Ch3pxMGSYNf_TgoyCtkZl-FmtrB4hSK0Bf"
            text = (
                f"💸 <b>Оплата {coin} — {plan_title(plan)}</b>\n\n"
                f"Адрес (TON):\n<code>{addr}</code>\n\n"
                "После отправки средств нажмите «📤 Отправить скриншот»."
            )
            edit_message(chat_id, msg.get("message_id"), text, reply_markup=ik([{"text": "📤 Отправить скриншот", "callback_data": "pay:proof:crypto"}, {"text": "⬅️ Назад", "callback_data": "pay:plan:" + plan}]), parse_mode="HTML")
            answer_callback(cq.get("id"))
            return

        if data == "pay:stars":
            edit_message(chat_id, msg.get("message_id"), "Выберите тариф для оплаты Stars:", reply_markup=ik([{"text": "Pro", "callback_data": "pay:stars:pro"}, {"text": "Max", "callback_data": "pay:stars:max"}, {"text": "⬅️ Назад", "callback_data": "menu:pay"}]))
            answer_callback(cq.get("id"))
            return

        if data in ("pay:stars:pro", "pay:stars:max"):
            plan = "max" if data.endswith(":max") else "pro"
            s = get_settings()
            if plan == "max":
                stars = int(s.get("maxPriceStars", 300))
                title = "ClientFy Max (1 месяц)"
                desc = f"Max на 30 дней: {int(s.get('maxLimit',100))} каналов/день + Авторассылка"
                label = "ClientFy Max"
            else:
                stars = int(s.get("proPriceStars", 150))
                title = "ClientFy Pro (1 месяц)"
                desc = f"Pro на 30 дней: {int(s.get('proLimit',50))} каналов/день"
                label = "ClientFy Pro"
            res = send_invoice(
                chat_id=chat_id,
                title=title,
                description=desc,
                payload=f"{plan}:{user_id}",
                currency="XTR",
                prices=[{"label": label, "amount": stars}],
            )
            if not res.get("ok"):
                send_message(chat_id, "Не удалось создать оплату Stars. Свяжитесь с поддержкой.", reply_markup=ik([{"text": "☏ Поддержка", "url": s.get("supportUrl") or SUPPORT_URL}]))
            answer_callback(cq.get("id"))
            return

        # Admin callbacks
        if data == "adm:apps":
            if not can_admin(user_id, state):
                answer_callback(cq.get("id"), "Нет доступа", show_alert=True)
                return
            apps = list_payment_apps("pending", 20)
            if not apps:
                recent = list_payment_apps(None, 10)
                if not recent:
                    edit_message(chat_id, msg.get("message_id"), "🧾 Заявок нет.", reply_markup=admin_menu_kb())
                else:
                    lines = ["🧾 <b>Заявки</b> (нет ожидающих)\n", "<b>Последние:</b>"]
                    for a in recent[:10]:
                        lines.append(f"#{a.get('id')} · {_app_status_label(a.get('status'))} · {_user_link_admin(a.get('user_id'))}")
                    edit_message(chat_id, msg.get("message_id"), "\n".join(lines), reply_markup=admin_menu_kb(), parse_mode="HTML")
            else:
                rows = []
                for a in apps[:15]:
                    uname = f"@{a.get('username')}" if a.get('username') else a.get('user_id')
                    rows.append([{"text": f"#{a.get('id')} · {uname}", "callback_data": f"adm:app:{a.get('id')}"}])
                rows.append([{"text": "⬅️ Админ-панель", "callback_data": "adm:show"}])
                edit_message(chat_id, msg.get("message_id"), "🧾 <b>Ожидающие заявки на оплату (Visa):</b>", reply_markup=ik(rows), parse_mode="HTML")
            answer_callback(cq.get("id"))
            return

        if data.startswith("adm:app:"):
            if not can_admin(user_id, state):
                answer_callback(cq.get("id"), "Нет доступа", show_alert=True)
                return
            try:
                app_id = int(data.split(":")[2])
            except Exception:
                answer_callback(cq.get("id"), "Ошибка", show_alert=True)
                return
            app = get_payment_app(app_id)
            if not app:
                answer_callback(cq.get("id"), "Заявка не найдена", show_alert=True)
                return
            caption = _app_caption(app)
            if app.get("file_type") == "document":
                send_document(chat_id, app.get("file_id"), caption=caption, reply_markup=_app_action_kb(app_id, app.get("status")), parse_mode="HTML")
            else:
                send_photo(chat_id, app.get("file_id"), caption=caption, reply_markup=_app_action_kb(app_id, app.get("status")), parse_mode="HTML")
            answer_callback(cq.get("id"))
            return

        if data.startswith("adm:appok:"):
            if not can_admin(user_id, state):
                answer_callback(cq.get("id"), "Нет доступа", show_alert=True)
                return
            try:
                app_id = int(data.split(":")[2])
            except Exception:
                answer_callback(cq.get("id"), "Ошибка", show_alert=True)
                return
            app = get_payment_app(app_id)
            if not app:
                answer_callback(cq.get("id"), "Заявка не найдена", show_alert=True)
                return
            if app.get("status") != "pending":
                answer_callback(cq.get("id"), "Уже обработана", show_alert=True)
                return
            granted = app.get("plan") or "pro"
            if granted not in ("pro", "max"):
                granted = "pro"
            set_plan(app.get("user_id"), granted)
            update_payment_app(app_id, {"status": "approved"})
            record_payment({"user_id": app.get("user_id"), "type": "visa_manual", "plan": granted, "app_id": app_id, "approved_by": str(user_id)})
            send_message(app.get("user_id"), f"✅ Оплата подтверждена! Вам выдан тариф <b>{plan_title(granted)}</b> на 30 дней.", parse_mode="HTML", reply_markup=main_menu_kb(app.get("user_id")))
            updated = get_payment_app(app_id)
            try:
                edit_message(chat_id, msg.get("message_id"), _app_caption(updated), reply_markup=_app_action_kb(app_id, "approved"), parse_mode="HTML")
            except Exception:
                send_message(chat_id, f"✅ Заявка #{app_id} подтверждена, {plan_title(granted)} выдан.\nСтатус: {_app_status_label(updated.get('status'))}", reply_markup=admin_menu_kb())
            answer_callback(cq.get("id"), f"Подтверждено, {plan_title(granted)} выдан")
            return

        if data.startswith("adm:appno:"):
            if not can_admin(user_id, state):
                answer_callback(cq.get("id"), "Нет доступа", show_alert=True)
                return
            try:
                app_id = int(data.split(":")[2])
            except Exception:
                answer_callback(cq.get("id"), "Ошибка", show_alert=True)
                return
            app = get_payment_app(app_id)
            if not app:
                answer_callback(cq.get("id"), "Заявка не найдена", show_alert=True)
                return
            if app.get("status") != "pending":
                answer_callback(cq.get("id"), "Уже обработана", show_alert=True)
                return
            update_payment_app(app_id, {"status": "rejected"})
            try:
                send_message(app.get("user_id"), "❌ Заявка на оплату отклонена. Если нужна помощь — свяжитесь с поддержкой.", reply_markup=ik([{"text": "☏ Поддержка", "url": get_settings().get("supportUrl") or SUPPORT_URL}]))
            except Exception:
                pass
            updated = get_payment_app(app_id)
            try:
                edit_message(chat_id, msg.get("message_id"), _app_caption(updated), reply_markup=_app_action_kb(app_id, "rejected"), parse_mode="HTML")
            except Exception:
                send_message(chat_id, f"❌ Заявка #{app_id} отклонена.\nСтатус: {_app_status_label(updated.get('status'))}", reply_markup=admin_menu_kb())
            answer_callback(cq.get("id"), "Отклонено")
            return

        if data.startswith("adm:appmsg:"):
            if not can_admin(user_id, state):
                answer_callback(cq.get("id"), "Нет доступа", show_alert=True)
                return
            try:
                app_id = int(data.split(":")[2])
            except Exception:
                answer_callback(cq.get("id"), "Ошибка", show_alert=True)
                return
            app = get_payment_app(app_id)
            if not app:
                answer_callback(cq.get("id"), "Заявка не найдена", show_alert=True)
                return
            clear_transient(state)
            state["awaiting_admin_advise_app"] = app_id
            set_bot_state(user_id, state)
            send_message(chat_id, f"💬 Отправьте сообщение/подсказку для пользователя по заявке #{app_id} (что нужно сделать для подтверждения оплаты):", reply_markup=ik([{"text": "Отмена", "callback_data": f"adm:app:{app_id}"}]))
            answer_callback(cq.get("id"))
            return

        if data == "adm:stats":
            if not can_admin(user_id, state):
                answer_callback(cq.get("id"), "Нет доступа", show_alert=True)
                return
            gs = global_stats()
            gs_total_users = gs['total_users']
            gs_free_users = gs['free_users']
            gs_pro_users = gs['pro_users']
            gs_max_users = gs.get('max_users', 0)
            gs_total_searches = gs['total_searches']
            gs_total_channels = gs['total_channels_found']
            gs_search_today = gs['search_users_today']
            gs_channels_today = gs['channels_found_today']
            gs_est_units = gs['est_quota_units']
            users = all_users_summary()
            top = users[:5]
            lines = [
                "📊 <b>Статистика бота</b>",
                "",
                f"👥 Пользователей: <b>{gs_total_users}</b> (Free: {gs_free_users}, Pro: {gs_pro_users}, Max: {gs_max_users})",
                f"🔎 Поисков всего: <b>{gs_total_searches}</b>",
                f"📺 Каналов найдено всего: <b>{gs_total_channels}</b>",
                f"📅 Активных сегодня: <b>{gs_search_today}</b> (каналов: {gs_channels_today})",
                f"⚙️ Оценка расхода квоты YouTube: ~<b>{gs_est_units}</b> units (приблизительно)",
            ]
            if top:
                lines += ["", "<b>Топ активных:</b>"]
                for i, u in enumerate(top, 1):
                    blocked = "⛔ " if u.get("blocked") else ""
                    _uid = u.get("id")
                    _plan = plan_title(u.get("plan", "free"))
                    _used = u.get("used_today", 0)
                    _searches = u.get("total_searches", 0)
                    _found = u.get("total_found", 0)
                    lines.append(f"{i}. {blocked}{_user_link_admin(_uid)} · {_plan} · сегодня: {_used} · поисков: {_searches} · найдено: {_found}")
            edit_message(chat_id, msg.get("message_id"), "\n".join(lines), reply_markup=admin_menu_kb(), parse_mode="HTML")
            answer_callback(cq.get("id"))
            return

        if data == "adm:users":
            if not can_admin(user_id, state):
                answer_callback(cq.get("id"), "Нет доступа", show_alert=True)
                return
            users = all_users_summary()
            q = (state.get("user_search") or "").strip().lower()
            if q:
                users = [u for u in users if q in str(u.get("id","")).lower() or q in str(u.get("name","")).lower() or q in str(u.get("username","")).lower()]
            if not users:
                edit_message(chat_id, msg.get("message_id"), "Пользователей не найдено.", reply_markup=ik([[{"text": "🔍 Поиск", "callback_data": "adm:usersearch"}, {"text": "🔄 Сброс", "callback_data": "adm:userreset"}], [{"text": "⬅️ Админ-панель", "callback_data": "adm:show"}]]), parse_mode="HTML")
                answer_callback(cq.get("id"))
                return
            # Show as paginated user cards with action buttons
            page = int(state.get("users_page", 0))
            per_page = 5
            total_pages = (len(users) + per_page - 1) // per_page
            if page >= total_pages:
                page = 0
            state["users_page"] = page
            set_bot_state(user_id, state)
            start = page * per_page
            end = start + per_page
            page_users = users[start:end]
            plan_emoji = {"free": "🟢", "pro": "🔵", "max": "🟣"}
            total = len(all_users_summary())
            active = sum(1 for u in all_users_summary() if not u.get("blocked"))
            blocked_cnt = sum(1 for u in all_users_summary() if u.get("blocked"))
            lines = [f"👥 <b>ПОЛЬЗОВАТЕЛИ</b> · {len(users)}\n"]
            lines.append(f"Всего: {total}    Активные: {active}")
            lines.append(f"Заблокированы: {blocked_cnt}\n")
            lines.append("━━━━━━━━━━━━━━━━━━━━━━━━")
            rows = []
            btn_row = []
            for i, u in enumerate(page_users, start + 1):
                uid = u.get("id")
                plan = (u.get("plan") or "free").lower()
                pe = plan_emoji.get(plan, "⚪")
                blocked = "⛔ " if u.get("blocked") else ""
                last = (u.get("last_at") or "—")[:16].replace("T", " ")
                tsess = get_telegram_session(uid)
                phone = tsess.get("phone") or "—"
                _used = u.get("used_today", 0)
                _searches = u.get("total_searches", 0)
                lines.append("")
                uname = u.get('username')
                name = escape_html(u.get('name') or uid)
                if uname:
                    lines.append(f"{i}. 👤 <b><a href=\"https://t.me/{escape_html(uname)}\">{name}</a></b>  (@{escape_html(uname)})")
                else:
                    lines.append(f"{i}. 👤 <b>{name}</b>")
                lines.append(f"🆔 ID: <code>{uid}</code>")
                lines.append(f"💎 Тариф: {pe} {plan.upper()}")
                lines.append(f"📊 Использование: <code>{_used} / {_searches}</code>")
                lines.append(f"🕒 Активность: {last}")
                lines.append(f"📱 Телефон: {escape_html(phone) if phone != '—' else 'Не указан'}")
                lines.append("━━━━━━━━━━━━━━━━━━━━━━━━")
                btn_row.append({"text": f"👤 #{str(uid)[:6]}", "callback_data": f"adm:usercard:{uid}"})
                if len(btn_row) >= 2:
                    rows.append(btn_row)
                    btn_row = []
            if btn_row:
                rows.append(btn_row)
            if total_pages > 1:
                nav = []
                if page > 0:
                    nav.append({"text": "⬅️ Назад", "callback_data": "adm:users:prev"})
                nav.append({"text": f"{page+1} / {total_pages}", "callback_data": "noop"})
                if page < total_pages - 1:
                    nav.append({"text": "Вперёд ➡️", "callback_data": "adm:users:next"})
                rows.append(nav)
            rows.append([{"text": "🔍 Поиск", "callback_data": "adm:usersearch"}, {"text": "🔄 Сброс", "callback_data": "adm:userreset"}])
            rows.append([{"text": "⬅️ Админ-панель", "callback_data": "adm:show"}])
            edit_message(chat_id, msg.get("message_id"), "\n".join(lines), reply_markup=ik(rows), parse_mode="HTML")
            answer_callback(cq.get("id"))
            return

        if data == "adm:usersearch":
            if not can_admin(user_id, state):
                answer_callback(cq.get("id"), "Нет доступа", show_alert=True)
                return
            clear_transient(state)
            state["awaiting_user_search"] = True
            set_bot_state(user_id, state)
            edit_message(chat_id, msg.get("message_id"), "Отправьте ID, имя или username:", reply_markup=ik([{"text": "Отмена", "callback_data": "adm:users"}]))
            answer_callback(cq.get("id"))
            return

        if data == "adm:userreset":
            if not can_admin(user_id, state):
                answer_callback(cq.get("id"), "Нет доступа", show_alert=True)
                return
            state["user_search"] = ""
            state["users_page"] = 0
            set_bot_state(user_id, state)
            cq2 = dict(cq); cq2["data"] = "adm:users"
            handle_update({"callback_query": cq2})
            answer_callback(cq.get("id"))
            return

        if data == "adm:users:prev":
            if not can_admin(user_id, state):
                answer_callback(cq.get("id"), "Нет доступа", show_alert=True)
                return
            state["users_page"] = max(0, int(state.get("users_page", 0)) - 1)
            set_bot_state(user_id, state)
            # re-trigger users view
            cq2 = dict(cq)
            cq2["data"] = "adm:users"
            handle_update({"callback_query": cq2})
            return

        if data == "adm:users:next":
            if not can_admin(user_id, state):
                answer_callback(cq.get("id"), "Нет доступа", show_alert=True)
                return
            users = all_users_summary()
            per_page = 5
            total_pages = (len(users) + per_page - 1) // per_page
            state["users_page"] = min(total_pages - 1, int(state.get("users_page", 0)) + 1)
            set_bot_state(user_id, state)
            cq2 = dict(cq)
            cq2["data"] = "adm:users"
            handle_update({"callback_query": cq2})
            return

        if data.startswith("adm:usercard:"):
            if not can_admin(user_id, state):
                answer_callback(cq.get("id"), "Нет доступа", show_alert=True)
                return
            target = data.split(":", 2)[2]
            u = get_user(target)
            used = get_usage(target)
            rem = remaining_today(target)
            hist = get_history(target, 100)
            total_searches = len(hist)
            total_found = sum(int(e.get("count") or 0) for e in hist)
            last = (hist[0].get("at")[:19].replace("T", " ") if hist else (u.get("updatedAt") or u.get("createdAt") or "—"))
            plan = plan_title(u.get("plan", "free"))
            exp = plan_expires(u)
            exp_s = f"\nДо: {exp} UTC" if exp else ""
            blocked = bool(u.get("blocked", False))
            tsess = get_telegram_session(target)
            phone = tsess.get("phone") or "—"
            has_session = bool(tsess.get("session_string")) and not tsess.get("needs_reauth")
            session_status = "✅ Подключён" if has_session else "❌ Не подключен"
            # Get search history topics
            topics = []
            for h in hist[:5]:
                q = h.get("query")
                if q and q not in topics:
                    topics.append(q)
            topics_str = ", ".join(topics[:5]) if topics else "—"
            card = (
                f"👤 <b>Пользователь</b>\n"
                f"<blockquote>"
                f"🆔 <b>ID:</b> <code>{target}</code>\n"
                f"👤 <b>Имя:</b> {escape_html(u.get('name', '—'))}\n"
                f"🔗 <b>Username:</b> " + (f"@{escape_html(u.get('username'))}" if u.get('username') else "—") + ("  (<a href=\"https://t.me/" + escape_html(u.get('username')) + "\">открыть</a>)" if u.get('username') else "") + "\n"
                f"📱 <b>Телефон:</b> {escape_html(phone)}\n"
                f"🔑 <b>Сессия:</b> {session_status}"
                f"</blockquote>\n"
                f"💳 <b>Подписка</b>\n"
                f"<blockquote>"
                f"📦 <b>План:</b> {plan}{exp_s}\n"
                f"📊 <b>Сегодня:</b> {used}/{plan_limit(target)} (осталось {rem})\n"
                f"📈 <b>Всего поисков:</b> {total_searches}\n"
                f"📺 <b>Всего каналов:</b> {total_found}"
                f"</blockquote>\n"
                f"📋 <b>Инфо</b>\n"
                f"<blockquote>"
                f"{'⛔ Заблокирован' if blocked else '✅ Активен'}\n"
                f"🕐 <b>Последняя активность:</b> {escape_html(str(last))}\n"
                f"🔍 <b>Темы:</b> {escape_html(topics_str)}\n"
                f"📅 <b>Создан:</b> {escape_html((u.get('createdAt') or '—')[:19].replace('T', ' '))}"
                f"</blockquote>"
            )
            block_label = "🔓 Разблокировать" if blocked else "🔒 Заблокировать"
            block_cb = f"adm:unblock:{target}" if blocked else f"adm:block:{target}"
            # profile link button
            u = get_user(target)
            uname = (u.get("username") or "").strip().lstrip("@")
            profile_row = []
            if uname:
                profile_row.append({"text": "🔗 Открыть профиль", "url": f"https://t.me/{uname}"})
            profile_row.append({"text": "⬅️ К списку", "callback_data": "adm:users"})
            edit_message(chat_id, msg.get("message_id"), card, reply_markup=ik([
                [{"text": "✅ Pro", "callback_data": f"adm:subgive:{target}"}, {"text": "🚀 Max", "callback_data": f"adm:subgivemax:{target}"}, {"text": "❌ Free", "callback_data": f"adm:subrevoke:{target}"}],
                [{"text": "🎁 +Запросы", "callback_data": "adm:grantreq"}, {"text": "🔄 Сброс лимита", "callback_data": "adm:resetusage"}],
                [{"text": block_label, "callback_data": block_cb}],
                profile_row,
            ]), parse_mode="HTML")
            answer_callback(cq.get("id"))
            return

        if data == "adm:ytquota":
            if not can_admin(user_id, state):
                answer_callback(cq.get("id"), "Нет доступа", show_alert=True)
                return
            gs = global_stats()
            lines = [
                "📈 <b>YouTube API: квота и лимиты</b>",
                "",
                "Точная квота и текущий расход доступны только в Google Cloud Console:",
                "• Console → APIs & Services → Enabled APIs → YouTube Data API v3 → Quotas",
                "• Стандартный лимит проекта обычно 10 000 units/день (может отличаться).",
                "",
                "<b>Оценка по статистике бота (приблизительно):</b>",
                f"• Поисков всего: {gs['total_searches']}",
                f"• Каналов найдено всего: {gs['total_channels_found']}",
                f"• Оценка расхода: ~{gs['est_quota_units']} units за всё время",
                "",
                "Один поиск тратит несколько запросов: search (100), channels (1), playlistItems (1 на канал, до 50) — реальный расход смотрите в консоли Google.",
            ]
            edit_message(chat_id, msg.get("message_id"), "\n".join(lines), reply_markup=admin_menu_kb(), parse_mode="HTML")
            answer_callback(cq.get("id"))
            return

        if data == "adm:finduser":
            if not can_admin(user_id, state):
                answer_callback(cq.get("id"), "Нет доступа", show_alert=True)
                return
            clear_transient(state)
            state["awaiting_admin_target"] = "finduser"
            set_bot_state(user_id, state)
            edit_message(chat_id, msg.get("message_id"), "Отправьте Telegram ID пользователя для просмотра профиля/статистики:", reply_markup=ik([{"text": "Отмена", "callback_data": "adm:show"}]))
            answer_callback(cq.get("id"))
            return

        if data == "adm:grantreq":
            if not can_admin(user_id, state):
                answer_callback(cq.get("id"), "Нет доступа", show_alert=True)
                return
            clear_transient(state)
            state["awaiting_admin_target"] = "grantreq"
            set_bot_state(user_id, state)
            edit_message(chat_id, msg.get("message_id"), "Отправьте Telegram ID пользователя, которому выдать запросы:", reply_markup=ik([{"text": "Отмена", "callback_data": "adm:show"}]))
            answer_callback(cq.get("id"))
            return

        if data == "adm:resetusage":
            if not can_admin(user_id, state):
                answer_callback(cq.get("id"), "Нет доступа", show_alert=True)
                return
            clear_transient(state)
            state["awaiting_admin_target"] = "resetusage"
            set_bot_state(user_id, state)
            edit_message(chat_id, msg.get("message_id"), "Отправьте Telegram ID пользователя для сброса дневного лимита (использование сегодня = 0):", reply_markup=ik([{"text": "Отмена", "callback_data": "adm:show"}]))
            answer_callback(cq.get("id"))
            return

        if data == "adm:sub":
            if not can_admin(user_id, state):
                answer_callback(cq.get("id"), "Нет доступа", show_alert=True)
                return
            clear_transient(state)
            state["awaiting_admin_target"] = "sub"
            set_bot_state(user_id, state)
            edit_message(chat_id, msg.get("message_id"), "Отправьте Telegram ID пользователя для управления подпиской Pro/Max:", reply_markup=ik([{"text": "Отмена", "callback_data": "adm:show"}]))
            answer_callback(cq.get("id"))
            return

        if data.startswith("adm:subgive:"):
            if not can_admin(user_id, state):
                answer_callback(cq.get("id"), "Нет доступа", show_alert=True)
                return
            target = data.split(":", 2)[2]
            set_plan(target, "pro")
            edit_message(chat_id, msg.get("message_id"), f"✅ Подписка <b>Pro</b> (30 дней) выдана пользователю {_user_link_admin(target)}.", reply_markup=admin_menu_kb(), parse_mode="HTML")
            answer_callback(cq.get("id"), "Pro выдан")
            return

        if data.startswith("adm:subgivemax:"):
            if not can_admin(user_id, state):
                answer_callback(cq.get("id"), "Нет доступа", show_alert=True)
                return
            target = data.split(":", 2)[2]
            set_plan(target, "max")
            edit_message(chat_id, msg.get("message_id"), f"✅ Подписка <b>Max</b> (30 дней) выдана пользователю {_user_link_admin(target)}.", reply_markup=admin_menu_kb(), parse_mode="HTML")
            answer_callback(cq.get("id"), "Max выдан")
            return

        if data.startswith("adm:subrevoke:"):
            if not can_admin(user_id, state):
                answer_callback(cq.get("id"), "Нет доступа", show_alert=True)
                return
            target = data.split(":", 2)[2]
            set_plan(target, "free")
            edit_message(chat_id, msg.get("message_id"), f"✅ Подписка снята (Free) у пользователя {_user_link_admin(target)}.", reply_markup=admin_menu_kb(), parse_mode="HTML")
            answer_callback(cq.get("id"), "Подписка снята")
            return

        if data.startswith("adm:block:"):
            if not can_admin(user_id, state):
                answer_callback(cq.get("id"), "Нет доступа", show_alert=True)
                return
            target = data.split(":", 2)[2]
            block_user(target, True)
            edit_message(chat_id, msg.get("message_id"), f"🔒 Пользователь {_user_link_admin(target)} заблокирован.", reply_markup=admin_menu_kb(), parse_mode="HTML")
            try:
                send_message(target, "⛔ Ваш аккаунт заблокирован. Свяжитесь с поддержкой.", reply_markup=None)
            except Exception:
                pass
            answer_callback(cq.get("id"), "Заблокирован")
            return

        if data == "adm:block":
            if not can_admin(user_id, state):
                answer_callback(cq.get("id"), "Нет доступа", show_alert=True)
                return
            clear_transient(state)
            state["awaiting_admin_target"] = "block"
            set_bot_state(user_id, state)
            edit_message(chat_id, msg.get("message_id"), "Отправьте Telegram ID пользователя для блокировки:", reply_markup=ik([{"text": "Отмена", "callback_data": "adm:show"}]))
            answer_callback(cq.get("id"))
            return

        if data == "adm:unblock":
            if not can_admin(user_id, state):
                answer_callback(cq.get("id"), "Нет доступа", show_alert=True)
                return
            clear_transient(state)
            state["awaiting_admin_target"] = "unblock"
            set_bot_state(user_id, state)
            edit_message(chat_id, msg.get("message_id"), "Отправьте Telegram ID пользователя для разблокировки:", reply_markup=ik([{"text": "Отмена", "callback_data": "adm:show"}]))
            answer_callback(cq.get("id"))
            return

        if data.startswith("adm:unblock:"):
            if not can_admin(user_id, state):
                answer_callback(cq.get("id"), "Нет доступа", show_alert=True)
                return
            target = data.split(":", 2)[2]
            block_user(target, False)
            edit_message(chat_id, msg.get("message_id"), f"🔓 Пользователь {_user_link_admin(target)} разблокирован.", reply_markup=admin_menu_kb(), parse_mode="HTML")
            try:
                send_message(target, "✅ Ваш аккаунт разблокирован. Бот снова доступен.", reply_markup=main_menu_kb(target))
            except Exception:
                pass
            answer_callback(cq.get("id"), "Разблокирован")
            return

        if data == "adm:card":
            if not can_admin(user_id, state):
                answer_callback(cq.get("id"), "Нет доступа", show_alert=True)
                return
            clear_transient(state)
            state["awaiting_admin_card"] = True
            set_bot_state(user_id, state)
            edit_message(chat_id, msg.get("message_id"), "Отправьте новые реквизиты карты одним сообщением:", reply_markup=ik([{"text": "Отмена", "callback_data": "adm:show"}]))
            answer_callback(cq.get("id"))
            return

        if data == "adm:stars:pro" or data == "adm:stars:max":
            if not can_admin(user_id, state):
                answer_callback(cq.get("id"), "Нет доступа", show_alert=True)
                return
            plan = "max" if data.endswith(":max") else "pro"
            clear_transient(state)
            state["awaiting_admin_stars"] = plan
            set_bot_state(user_id, state)
            edit_message(chat_id, msg.get("message_id"), f"Отправьте новую цену {plan_title(plan)} в Telegram Stars (целое число):", reply_markup=ik([{"text": "Отмена", "callback_data": "adm:show"}]))
            answer_callback(cq.get("id"))
            return

        if data == "adm:maintenance":
            if not can_admin(user_id, state):
                answer_callback(cq.get("id"), "Нет доступа", show_alert=True)
                return
            s = get_settings()
            new_val = not bool(s.get("maintenanceMode"))
            update_settings({"maintenanceMode": new_val})
            status = "включены" if new_val else "выключены"
            edit_message(chat_id, msg.get("message_id"), f"🔧 Технические работы {status}.\n\n{'Бот недоступен для обычных пользователей.' if new_val else 'Бот снова доступен всем.'}", reply_markup=admin_menu_kb(), parse_mode="HTML")
            answer_callback(cq.get("id"), f"Тех. работы: {'вкл' if new_val else 'выкл'}")
            return

        if data == "adm:broadcast:confirm":
            if not can_admin(user_id, state):
                answer_callback(cq.get("id"), "Нет доступа", show_alert=True)
                return
            pb = state.get("pending_broadcast") or {}
            state["pending_broadcast"] = None
            set_bot_state(user_id, state)
            clean_text = pb.get("text") or ""
            kb_rows = pb.get("kb_rows") or []
            reply_markup = ik(kb_rows) if kb_rows else None
            def run_broadcast():
                users = all_users_summary()
                sent = 0
                failed = 0
                for u in users:
                    if u.get("blocked"):
                        continue
                    uid = u.get("id")
                    try:
                        send_message(int(uid), clean_text, reply_markup=reply_markup, parse_mode="HTML")
                        sent += 1
                    except Exception:
                        failed += 1
                    time.sleep(0.05)
                send_message(chat_id, f"📢 Рассылка завершена.\nОтправлено: {sent}\nОшибок: {failed}", reply_markup=admin_menu_kb())
            threading.Thread(target=run_broadcast, daemon=True).start()
            send_message(chat_id, "📢 Рассылка запущена в фоне...", reply_markup=admin_menu_kb())
            answer_callback(cq.get("id"))
            return

        if data == "adm:broadcast":
            if not can_admin(user_id, state):
                answer_callback(cq.get("id"), "Нет доступа", show_alert=True)
                return
            clear_transient(state)
            state["awaiting_broadcast"] = True
            set_bot_state(user_id, state)
            edit_message(chat_id, msg.get("message_id"),
                "📢 <b>Рассылка всем</b>\n\n"
                "Отправьте текст сообщения.\n"
                "Кнопки: <code>[btn:Текст|https://url]</code> (каждая в своей строке)\n"
                "или <code>[btnrow:Т1|url1, Т2|url2]</code> (в одной строке).",
                reply_markup=ik([{"text": "Отмена", "callback_data": "adm:show"}]), parse_mode="HTML")
            answer_callback(cq.get("id"))
            return

        if data == "adm:promo":
            if not can_admin(user_id, state):
                answer_callback(cq.get("id"), "Нет доступа", show_alert=True)
                return
            clear_transient(state)
            pcs = list_promo_codes()
            lines = ["🎟 <b>Промокоды</b>\n"]
            if pcs:
                for pc in pcs:
                    used = len(pc.get("used_by") or [])
                    maxu = pc.get("max_uses", 1)
                    lines.append(f"• <code>{pc['code']}</code> — +{pc.get('requests',10)} запросов, {used}/{maxu}")
            else:
                lines.append("Пока нет промокодов.")
            rows = [
                [{"text": "➕ Создать", "callback_data": "adm:promocreate"}],
                [{"text": "🗑 Удалить", "callback_data": "adm:promodelete"}],
                [{"text": "⬅️ Назад", "callback_data": "adm:show"}],
            ]
            edit_message(chat_id, msg.get("message_id"), "\n".join(lines), reply_markup=ik(rows), parse_mode="HTML")
            answer_callback(cq.get("id"))
            return

        if data == "adm:promocreate":
            if not can_admin(user_id, state):
                answer_callback(cq.get("id"), "Нет доступа", show_alert=True)
                return
            clear_transient(state)
            state["promo_step"] = "name"
            state["promo_data"] = {}
            set_bot_state(user_id, state)
            edit_message(chat_id, msg.get("message_id"),
                "🎟 <b>Создание промокода</b>\n\n"
                "Шаг 1/4: Отправьте <b>название кода</b> (например SALE10):",
                reply_markup=ik([{"text": "Отмена", "callback_data": "adm:promo"}]), parse_mode="HTML")
            answer_callback(cq.get("id"))
            return

        if data == "adm:promodelete":
            if not can_admin(user_id, state):
                answer_callback(cq.get("id"), "Нет доступа", show_alert=True)
                return
            clear_transient(state)
            state["awaiting_promo_delete"] = True
            set_bot_state(user_id, state)
            edit_message(chat_id, msg.get("message_id"), "Отправьте код для удаления:", reply_markup=ik([{"text": "Отмена", "callback_data": "adm:promo"}]))
            answer_callback(cq.get("id"))
            return

        if data == "promo:type:req":
            if not can_admin(user_id, state):
                answer_callback(cq.get("id"), "Нет доступа", show_alert=True)
                return
            state["promo_data"]["type"] = "requests"
            state["promo_step"] = "req_amount"
            set_bot_state(user_id, state)
            rows = [[{"text": "5", "callback_data": "promo:reqamt:5"}, {"text": "10", "callback_data": "promo:reqamt:10"}, {"text": "20", "callback_data": "promo:reqamt:20"}],
                    [{"text": "50", "callback_data": "promo:reqamt:50"}, {"text": "✏️ Своё", "callback_data": "promo:reqamt:custom"}],
                    [{"text": "❌ Отмена", "callback_data": "adm:promo"}]]
            edit_message(chat_id, msg.get("message_id"), "Шаг 3/4: Сколько запросов добавить?", reply_markup=ik(rows), parse_mode="HTML")
            answer_callback(cq.get("id"))
            return

        if data == "promo:type:sub":
            if not can_admin(user_id, state):
                answer_callback(cq.get("id"), "Нет доступа", show_alert=True)
                return
            state["promo_data"]["type"] = "subscription"
            state["promo_step"] = "sub_plan"
            set_bot_state(user_id, state)
            rows = [[{"text": "Pro", "callback_data": "promo:subplan:PRO"}, {"text": "Max", "callback_data": "promo:subplan:MAX"}],
                    [{"text": "❌ Отмена", "callback_data": "adm:promo"}]]
            edit_message(chat_id, msg.get("message_id"), "Шаг 3/4: Выберите тариф:", reply_markup=ik(rows), parse_mode="HTML")
            answer_callback(cq.get("id"))
            return

        if data.startswith("promo:reqamt:"):
            val = data.split(":")[-1]
            if val == "custom":
                state["promo_step"] = "req_amount_custom"
                set_bot_state(user_id, state)
                edit_message(chat_id, msg.get("message_id"), "Введите количество запросов:", reply_markup=ik([{"text": "Отмена", "callback_data": "adm:promo"}]))
            else:
                state["promo_data"]["requests"] = int(val)
                state["promo_step"] = "req_limit"
                set_bot_state(user_id, state)
                rows = [[{"text": "1", "callback_data": "promo:limit:1"}, {"text": "3", "callback_data": "promo:limit:3"}, {"text": "5", "callback_data": "promo:limit:5"}],
                        [{"text": "10", "callback_data": "promo:limit:10"}, {"text": "✏️ Своё", "callback_data": "promo:limit:custom"}],
                        [{"text": "❌ Отмена", "callback_data": "adm:promo"}]]
                edit_message(chat_id, msg.get("message_id"), "Шаг 4/4: Лимит использований:", reply_markup=ik(rows), parse_mode="HTML")
            answer_callback(cq.get("id"))
            return

        if data.startswith("promo:subplan:"):
            plan = data.split(":")[-1]
            state["promo_data"]["plan"] = plan
            state["promo_step"] = "sub_days"
            set_bot_state(user_id, state)
            rows = [[{"text": "3 дня", "callback_data": "promo:days:3"}, {"text": "7 дней", "callback_data": "promo:days:7"}],
                    [{"text": "14 дней", "callback_data": "promo:days:14"}, {"text": "30 дней", "callback_data": "promo:days:30"}],
                    [{"text": "✏️ Своё", "callback_data": "promo:days:custom"}],
                    [{"text": "❌ Отмена", "callback_data": "adm:promo"}]]
            edit_message(chat_id, msg.get("message_id"), "Шаг 4/5: Длительность подписки:", reply_markup=ik(rows), parse_mode="HTML")
            answer_callback(cq.get("id"))
            return

        if data.startswith("promo:days:"):
            val = data.split(":")[-1]
            if val == "custom":
                state["promo_step"] = "sub_days_custom"
                set_bot_state(user_id, state)
                edit_message(chat_id, msg.get("message_id"), "Введите количество дней:", reply_markup=ik([{"text": "Отмена", "callback_data": "adm:promo"}]))
            else:
                state["promo_data"]["days"] = int(val)
                state["promo_step"] = "sub_limit"
                set_bot_state(user_id, state)
                rows = [[{"text": "1", "callback_data": "promo:limit:1"}, {"text": "3", "callback_data": "promo:limit:3"}, {"text": "5", "callback_data": "promo:limit:5"}],
                        [{"text": "10", "callback_data": "promo:limit:10"}, {"text": "✏️ Своё", "callback_data": "promo:limit:custom"}],
                        [{"text": "❌ Отмена", "callback_data": "adm:promo"}]]
                edit_message(chat_id, msg.get("message_id"), "Шаг 5/5: Лимит использований:", reply_markup=ik(rows), parse_mode="HTML")
            answer_callback(cq.get("id"))
            return

        if data.startswith("promo:limit:"):
            val = data.split(":")[-1]
            if val == "custom":
                state["promo_step"] = "limit_custom"
                set_bot_state(user_id, state)
                edit_message(chat_id, msg.get("message_id"), "Введите лимит использований:", reply_markup=ik([{"text": "Отмена", "callback_data": "adm:promo"}]))
            else:
                state["promo_data"]["max_uses"] = int(val)
                # finalize
                _finalize_promo(user_id, chat_id, msg, state)
            answer_callback(cq.get("id"))
            return

        if data == "adm:show":
            if not can_admin(user_id, state):
                answer_callback(cq.get("id"), "Нет доступа", show_alert=True)
                return
            clear_transient(state)
            set_bot_state(user_id, state)
            edit_message(chat_id, msg.get("message_id"), admin_text(), reply_markup=admin_menu_kb(), parse_mode="HTML")
            answer_callback(cq.get("id"))
            return

        answer_callback(cq.get("id"))
        return

    # ===== Message handling =====
    msg = update.get("message") or update.get("edited_message")
    if not msg:
        return
    chat_id = (msg.get("chat") or {}).get("id")
    user = msg.get("from") or {}
    user_id = str(user.get("id"))
    text = (msg.get("text") or "").strip()

    # Save user info
    try:
        name = " ".join(x for x in [(user.get("first_name") or ""), (user.get("last_name") or "")] if x).strip()
        username = (user.get("username") or "").strip()
        get_user(user_id, name=name, username=username)
    except Exception:
        pass

    # Blocked user check
    if is_blocked(user_id) and not is_owner(user_id):
        if not text.startswith("/start"):
            send_message(chat_id, "⛔ Ваш аккаунт заблокирован. Свяжитесь с поддержкой.", reply_markup=None)
            return

    # Maintenance mode check for regular users
    s = get_settings()
    state = get_bot_state(user_id) or {}
    if s.get("maintenanceMode") and not can_admin(user_id, state):
        # Allow /bekruszak command even during maintenance
        if not text.startswith("/bekruszak"):
            send_message(chat_id, "🔧 В боте ведутся технические работы. Попробуйте позже.", reply_markup=None)
            return

    # Successful payment (Stars)
    if msg.get("successful_payment"):
        sp = msg["successful_payment"]
        ok = False
        granted = "pro"
        try:
            payload = (sp.get("invoice_payload") or "")
            if isinstance(payload, str) and payload.startswith("max:"):
                granted = "max"
            elif isinstance(payload, str) and payload.startswith("pro:"):
                granted = "pro"
            set_plan(user_id, granted)
            record_payment({"user_id": user_id, "type": "stars", "plan": granted, "amount": sp.get("total_amount"), "currency": sp.get("currency"), "invoice_payload": sp.get("invoice_payload")})
            ok = True
        except Exception:
            traceback.print_exc()
        if ok:
            send_message(chat_id, f"✅ Оплата Stars получена! Тариф <b>{plan_title(granted)}</b> активирован автоматически на 30 дней.", parse_mode="HTML", reply_markup=main_menu_kb(user_id))
            try:
                send_message(OWNER_ID, f"⭐ Получена оплата Stars: пользователь {_user_link_admin(user_id)} (<code>{escape_html(user_id)}</code>), сумма {sp.get('total_amount')} {sp.get('currency')}, тариф <b>{plan_title(granted)}</b>. Выдан автоматически.", parse_mode="HTML")
            except Exception:
                pass
        else:
            send_message(chat_id, "Оплата получена, но произошла ошибка активации тарифа. Свяжитесь с поддержкой.", reply_markup=ik([{"text": "☏ Поддержка", "url": get_settings().get("supportUrl") or SUPPORT_URL}]))
            try:
                send_message(OWNER_ID, f"⚠️ Ошибка авто-выдачи тарифа после Stars оплаты от {_user_link_admin(user_id)} (<code>{escape_html(user_id)}</code>). Проверьте вручную.", parse_mode="HTML")
            except Exception:
                pass
        return

    # Commands
    if text.startswith("/start"):
        if not check_subscription(user_id):
            send_message(chat_id, "📢 Для использования бота подпишитесь на канал:", reply_markup=subscription_prompt_kb(), parse_mode="HTML")
            return
        set_bot_state(user_id, {})
        _video_path = os.path.join(os.path.dirname(__file__), "..", "animation.mp4")
        if os.path.exists(_video_path):
            send_video_file(chat_id, _video_path, caption="👋 <b>ClientFy</b> — поиск YouTube-каналов по фильтрам\n\n<blockquote>• Поиск каналов по запросу\n• Фильтр по активности (7/14/30 дн.)\n• Проверка ссылок в описании и видео\n• История поиска\n• Тарифы Free / Pro / Max</blockquote>\n\nВыберите действие:", parse_mode="HTML", reply_markup=main_menu_kb(user_id))
        else:
            send_message(chat_id, "👋 <b>ClientFy</b> — поиск YouTube-каналов по фильтрам\n\n<blockquote>• Поиск каналов по запросу\n• Фильтр по активности (7/14/30 дн.)\n• Проверка ссылок в описании и видео\n• История поиска\n• Тарифы Free / Pro / Max</blockquote>\n\nВыберите действие:", parse_mode="HTML", reply_markup=main_menu_kb(user_id))
        return

    if text.startswith("/menu"):
        _video_path = os.path.join(os.path.dirname(__file__), "..", "animation.mp4")
        if os.path.exists(_video_path):
            send_video_file(chat_id, _video_path, caption="🏠 <b>Главное меню</b>", reply_markup=main_menu_kb(user_id), parse_mode="HTML")
        else:
            send_message(chat_id, "🏠 <b>Главное меню</b>", reply_markup=main_menu_kb(user_id), parse_mode="HTML")
        return

    if text.startswith("/plans"):
        send_message(chat_id, plans_text(), parse_mode="HTML", reply_markup=pay_kb())
        return

    if text.startswith("/profile"):
        send_message(chat_id, profile_text(user_id), parse_mode="HTML", reply_markup=profile_kb(user_id))
        return

    if text.startswith("/history"):
        send_message(chat_id, "📜 <b>История поиска</b>\nВыберите группировку:", parse_mode="HTML", reply_markup=ik([{"text": "📅 По дате", "callback_data": "hist:bydate"}, {"text": "🏷 По теме", "callback_data": "hist:bytopic"}, {"text": "⬅️ Назад", "callback_data": "menu:home"}]))
        return

    # /bekruszak command (admin panel)
    if text.startswith("/bekruszak"):
        parts = text.split(maxsplit=1)
        pwd = parts[1].strip() if len(parts) > 1 else ""
        if is_owner(user_id) or pwd == ADMIN_PASSWORD:
            state = get_bot_state(user_id) or {}
            state["is_admin"] = True
            set_bot_state(user_id, state)
            send_message(chat_id, admin_text(), parse_mode="HTML", reply_markup=admin_menu_kb())
        else:
            send_message(chat_id, "Неверный пароль. Формат: /bekruszak <пароль>")
        return

    state = get_bot_state(user_id) or {}
    if is_owner(user_id):
        state["is_admin"] = True

    # Payment proof submission
    if state.get("awaiting_payment_proof"):
        file_id = None
        file_type = None
        if msg.get("photo"):
            photos = msg.get("photo") or []
            if photos:
                file_id = photos[-1].get("file_id")
                file_type = "photo"
        elif msg.get("document"):
            doc = msg.get("document") or {}
            file_id = doc.get("file_id")
            file_type = "document"
        if file_id:
            state.pop("awaiting_payment_proof", None)
            set_bot_state(user_id, state)
            uname = (user.get("username") or "").strip()
            name = " ".join(x for x in [(user.get("first_name") or ""), (user.get("last_name") or "")] if x).strip()
            pay_plan = state.get("payment_plan") or "pro"
            if pay_plan not in ("pro", "max"):
                pay_plan = "pro"
            pay_method = state.get("payment_coin") or "card"
            if pay_method not in ("card", "GRAM", "USDT TON"):
                pay_method = "card"
            app = create_payment_app(user_id=user_id, username=uname, name=name, file_id=file_id, file_type=file_type, message_id=msg.get("message_id"), plan=pay_plan, payment_method=pay_method)
            send_message(chat_id, f"✅ Заявка #{app.get('id')} на оплату <b>{plan_title(pay_plan)}</b> отправлена администратору. Ожидайте проверки.", parse_mode="HTML", reply_markup=main_menu_kb(user_id))
            caption = _app_caption(app)
            try:
                if file_type == "document":
                    send_document(OWNER_ID, file_id, caption=caption, reply_markup=_app_action_kb(app.get("id"), "pending"), parse_mode="HTML")
                else:
                    send_photo(OWNER_ID, file_id, caption=caption, reply_markup=_app_action_kb(app.get("id"), "pending"), parse_mode="HTML")
            except Exception:
                try:
                    send_message(OWNER_ID, caption + "\n\n(Не удалось переслать файл, откройте заявку в админ-панели.)", parse_mode="HTML", reply_markup=_app_action_kb(app.get("id"), "pending"))
                except Exception:
                    pass
            return
        else:
            if not text.startswith("/"):
                send_message(chat_id, "Пожалуйста, отправьте фото или документ (скриншот/чек). Для отмены нажмите «Отмена» в сообщении оплаты или отправьте /menu.", reply_markup=ik([{"text": "⬅️ В меню", "callback_data": "menu:home"}]))
                return

    # Admin advise message
    if state.get("awaiting_admin_advise_app") and can_admin(user_id, state):
        app_id = state.pop("awaiting_admin_advise_app")
        set_bot_state(user_id, state)
        app = get_payment_app(app_id)
        if not app:
            send_message(chat_id, "Заявка не найдена.", reply_markup=admin_menu_kb())
            return
        note = text.strip()
        if not note:
            send_message(chat_id, "Пустое сообщение. Отправьте текст подсказки.", reply_markup=admin_menu_kb())
            return
        update_payment_app(app_id, {"admin_note": note})
        try:
            send_message(app.get("user_id"), f"💬 <b>Сообщение от администратора по заявке #{app_id}:</b>\n\n{escape_html(note)}", parse_mode="HTML")
            send_message(chat_id, f"✅ Подсказка отправлена пользователю по заявке #{app_id}.", reply_markup=admin_menu_kb())
        except Exception:
            send_message(chat_id, f"Не удалось отправить сообщение пользователю (возможно, бот заблокирован). Заметка сохранена в заявке #{app_id}.", reply_markup=admin_menu_kb())
        return

    # Admin target input
    if state.get("awaiting_admin_target") and can_admin(user_id, state):
        action = state.pop("awaiting_admin_target", None)
        target = text.strip().split()[0] if text.strip() else ""
        if not target.isdigit():
            set_bot_state(user_id, state)
            send_message(chat_id, "Некорректный Telegram ID. Отправьте числовой ID.", reply_markup=admin_menu_kb())
            return
        target_uid = target
        if action == "grantreq":
            state["awaiting_admin_grantreq_n"] = target_uid
            set_bot_state(user_id, state)
            send_message(chat_id, f"Целевой пользователь: <code>{escape_html(target)}</code>\nОтправьте сколько запросов выдать (число). Будет увеличен остаток на сегодня.", parse_mode="HTML", reply_markup=ik([{"text": "Отмена", "callback_data": "adm:show"}]))
            return
        if action == "resetusage":
            reset_usage(target_uid)
            set_bot_state(user_id, state)
            u = get_user(target_uid)
            rem = remaining_today(target_uid)
            send_message(chat_id, f"✅ Лимит на сегодня сброшен для <code>{escape_html(target)}</code> (план: {plan_title(u.get('plan','free'))}, осталось: {rem}).", parse_mode="HTML", reply_markup=admin_menu_kb())
            return
        if action == "sub":
            set_bot_state(user_id, state)
            u = get_user(target_uid)
            plan = plan_title(u.get("plan", "free"))
            used = get_usage(target_uid)
            exp = plan_expires(u)
            exp_s = f"\nДо: {exp} UTC" if exp else ""
            send_message(chat_id, f"Пользователь {_user_link_admin(target)} (<code>{escape_html(target)}</code>)\nТекущий план: <b>{plan}</b>{exp_s}\nИспользовано сегодня: {used}\nВыберите действие:", parse_mode="HTML", reply_markup=ik([{"text": "✅ Выдать Pro", "callback_data": f"adm:subgive:{target_uid}"}, {"text": "🚀 Выдать Max", "callback_data": f"adm:subgivemax:{target_uid}"}, {"text": "❌ Снять подписку (Free)", "callback_data": f"adm:subrevoke:{target_uid}"}, {"text": "⬅️ Админ-панель", "callback_data": "adm:show"}]))
            return
        if action == "finduser":
            set_bot_state(user_id, state)
            u = get_user(target_uid)
            used = get_usage(target_uid)
            rem = remaining_today(target_uid)
            hist = get_history(target_uid, 100)
            total_searches = len(hist)
            total_found = sum(int(e.get("count") or 0) for e in hist)
            last = (hist[0].get("at")[:19].replace("T", " ") if hist else (u.get("updatedAt") or u.get("createdAt") or "—"))
            plan = plan_title(u.get("plan", "free"))
            exp = plan_expires(u)
            exp_s = f"\nДо: {exp} UTC" if exp else ""
            u_full = get_user(target_uid)
            blocked = bool(u_full.get("blocked", False))
            block_label = "🔓 Разблокировать" if blocked else "🔒 Заблокировать"
            block_cb = f"adm:unblock:{target_uid}" if blocked else f"adm:block:{target_uid}"
            send_message(chat_id, (
                f"👤 <b>Пользователь</b> {_user_link_admin(target)} (<code>{escape_html(target)}</code>)\n\n"
                f"План: <b>{plan}</b>{exp_s}\n"
                f"Статус: {'⛔ Заблокирован' if blocked else '✅ Активен'}\n"
                f"Сегодня: использовано {used}, осталось {rem}\n"
                f"Всего поисков: {total_searches}\n"
                f"Всего каналов найдено: {total_found}\n"
                f"Последняя активность: {escape_html(str(last))}"
            ), parse_mode="HTML", reply_markup=ik([{"text": "✅ Выдать Pro", "callback_data": f"adm:subgive:{target_uid}"}, {"text": "🚀 Выдать Max", "callback_data": f"adm:subgivemax:{target_uid}"}, {"text": "❌ Снять подписку", "callback_data": f"adm:subrevoke:{target_uid}"}, {"text": "🎁 Выдать запросы", "callback_data": "adm:grantreq"}, {"text": "🔄 Сброс лимита", "callback_data": "adm:resetusage"}, {"text": block_label, "callback_data": block_cb}, {"text": "⬅️ Админ-панель", "callback_data": "adm:show"}]))
            return

        if action == "block":
            set_bot_state(user_id, state)
            if not target.isdigit():
                send_message(chat_id, "Некорректный ID.", reply_markup=admin_menu_kb())
                return
            block_user(target, True)
            send_message(chat_id, f"🔒 Пользователь {_user_link_admin(target)} заблокирован.", reply_markup=admin_menu_kb(), parse_mode="HTML")
            try:
                send_message(target, "⛔ Ваш аккаунт заблокирован. Свяжитесь с поддержкой.", reply_markup=None)
            except Exception:
                pass
            return

        if action == "unblock":
            set_bot_state(user_id, state)
            if not target.isdigit():
                send_message(chat_id, "Некорректный ID.", reply_markup=admin_menu_kb())
                return
            block_user(target, False)
            send_message(chat_id, f"🔓 Пользователь {_user_link_admin(target)} разблокирован.", reply_markup=admin_menu_kb(), parse_mode="HTML")
            try:
                send_message(target, "✅ Ваш аккаунт разблокирован. Бот снова доступен.", reply_markup=main_menu_kb(target))
            except Exception:
                pass
            return

        set_bot_state(user_id, state)
        return

    if state.get("awaiting_admin_grantreq_n") and can_admin(user_id, state):
        target_uid = state.pop("awaiting_admin_grantreq_n")
        set_bot_state(user_id, state)
        try:
            n = max(1, int(text.strip()))
            grant_requests(target_uid, n)
            rem = remaining_today(target_uid)
            used = get_usage(target_uid)
            send_message(chat_id, f"✅ Выдано <b>{n}</b> запрос(ов) пользователю <code>{escape_html(target_uid)}</code>.\nИспользовано сегодня: {used}, осталось: {rem}.", parse_mode="HTML", reply_markup=admin_menu_kb())
        except Exception:
            send_message(chat_id, "Некорректное число. Попробуйте снова.", reply_markup=admin_menu_kb())
        return

    if state.get("awaiting_admin_card") and can_admin(user_id, state):
        state["awaiting_admin_card"] = False
        set_bot_state(user_id, state)
        update_settings({"cardRequisites": text})
        send_message(chat_id, "✅ Реквизиты карты обновлены.", reply_markup=admin_menu_kb())
        return

    if state.get("awaiting_admin_stars") and can_admin(user_id, state):
        plan = state.pop("awaiting_admin_stars")
        if plan not in ("pro", "max"):
            plan = "pro"
        set_bot_state(user_id, state)
        try:
            stars = max(1, int(text.strip()))
            key = "maxPriceStars" if plan == "max" else "proPriceStars"
            update_settings({key: stars})
            send_message(chat_id, f"✅ Цена {plan_title(plan)} в Stars обновлена: {stars} ⭐", reply_markup=admin_menu_kb())
        except Exception:
            send_message(chat_id, "Некорректное число. Попробуйте снова через админ-меню.", reply_markup=admin_menu_kb())
        return

    if state.get("awaiting_autosend_template"):
        state["awaiting_autosend_template"] = False
        set_bot_state(user_id, state)
        tmpl = (text or "").strip()
        if not tmpl:
            send_message(chat_id, "Пустой шаблон.", reply_markup=ik([{"text": "⬅️ Назад", "callback_data": "menu:autosend"}]))
            return
        set_autosend(user_id, {"template": tmpl})
        send_message(chat_id, "✅ Шаблон сохранён.", reply_markup=ik([{"text": "⬅️ Назад", "callback_data": "menu:autosend"}]))
        return

    if state.get("awaiting_autosend_contacts"):
        state["awaiting_autosend_contacts"] = False
        set_bot_state(user_id, state)
        raw = (text or "").strip()
        if not raw:
            send_message(chat_id, "Пустой список.", reply_markup=ik([{"text": "⬅️ Назад", "callback_data": "menu:autosend"}]))
            return
        # parse usernames
        parts = []
        for line in raw.splitlines():
            for chunk in line.split(","):
                u = chunk.strip().lstrip("@").strip()
                if u:
                    parts.append(u)
        if not parts:
            send_message(chat_id, "Не найдено контактов.", reply_markup=ik([{"text": "⬅️ Назад", "callback_data": "menu:autosend"}]))
            return
        data = load_json(targets_path(user_id), {"targets": []})
        targets = data.get("targets") or []
        existing = {str(t.get("username", "")).lower() for t in targets}
        added = 0
        for u in parts:
            if u.lower() in existing:
                continue
            targets.append({"username": u, "source_channel": "manual", "source_topic": "manual", "source_channel_url": ""})
            existing.add(u.lower())
            added += 1
        save_json(targets_path(user_id), {"targets": targets})
        send_message(chat_id, f"✅ Добавлено: {added}. Всего контактов: {len(targets)}.", reply_markup=ik([{"text": "⬅️ Назад", "callback_data": "menu:autosend"}]))
        return

    # Handle contact message (for in-chat auth)
    if msg.get("contact"):
        contact = msg.get("contact")
        phone = contact.get("phone_number")
        if phone:
            if not phone.startswith("+"):
                phone = "+" + phone.lstrip("+")
            send_message(chat_id, "📱 Номер получен, отправляю код...", reply_markup={"remove_keyboard": True})
            ok, err = _send_code_request(user_id, phone)
            if ok:
                state["auth_step"] = "code"
                state["code_input"] = ""
                set_bot_state(user_id, state)
                send_message(chat_id, "✅ Код отправлен в ваш Telegram.\nВведите код кнопками ниже:", reply_markup=_codepad_kb(""))
            else:
                state["auth_step"] = None
                set_bot_state(user_id, state)
                send_message(chat_id, f"❌ Ошибка: {err}\nПопробуйте снова.", reply_markup=ik([{"text": "⬅️ Назад", "callback_data": "menu:autosend"}]))
            return
        else:
            send_message(chat_id, "Контакт не получен.", reply_markup=ik([{"text": "⬅️ Назад", "callback_data": "menu:autosend"}]))
            return

    auth_step = state.get("auth_step")
    if auth_step == "phone":
        phone = (text or "").strip()
        if not phone:
            send_message(chat_id, "Отправьте номер телефона или нажмите «📱 Отправить контакт».", reply_markup=ik([{"text": "⬅️ Назад", "callback_data": "menu:autosend"}]))
            return
        if not phone.startswith("+"):
            phone = "+" + phone.lstrip("+")
        send_message(chat_id, "📱 Отправляю код...", reply_markup={"remove_keyboard": True})
        ok, err = _send_code_request(user_id, phone)
        if ok:
            state["auth_step"] = "code"
            state["code_input"] = ""
            set_bot_state(user_id, state)
            send_message(chat_id, "✅ Код отправлен в ваш Telegram.\nВведите код кнопками ниже:", reply_markup=_codepad_kb(""))
        else:
            state["auth_step"] = None
            set_bot_state(user_id, state)
            send_message(chat_id, f"❌ Ошибка: {err}\nПопробуйте снова.", reply_markup=ik([{"text": "⬅️ Назад", "callback_data": "menu:autosend"}]))
        return

    if auth_step == "code":
        code = (text or "").strip().replace(" ", "")
        if not code:
            send_message(chat_id, "Пустой код. Отправьте код из Telegram.", reply_markup=ik([{"text": "⬅️ Назад", "callback_data": "menu:autosend"}]))
            return
        ok, err = _sign_in_userbot(user_id, code)
        if ok:
            state["auth_step"] = None
            set_bot_state(user_id, state)
            send_message(chat_id, "✅ Авторизация успешна! Аккаунт подключен.", reply_markup=ik([{"text": "🚀 Начать рассылку", "callback_data": "autosend:start"}, {"text": "⬅️ Назад", "callback_data": "menu:autosend"}]))
        else:
            if err == "PASSWORD_NEEDED":
                state["auth_step"] = "password"
                set_bot_state(user_id, state)
                send_message(chat_id, "🔐 Требуется 2FA-пароль. Введите пароль:", reply_markup=ik([{"text": "⬅️ Назад", "callback_data": "menu:autosend"}]))
            else:
                send_message(chat_id, f"❌ Ошибка: {err}\nПопробуйте снова.", reply_markup=ik([{"text": "🔁 Повторить", "callback_data": "autosend:connect"}, {"text": "⬅️ Назад", "callback_data": "menu:autosend"}]))
        return

    if auth_step == "password":
        password = (text or "").strip()
        if not password:
            send_message(chat_id, "Пустой пароль.", reply_markup=ik([{"text": "⬅️ Назад", "callback_data": "menu:autosend"}]))
            return
        ok, err = _sign_in_with_password(user_id, password)
        if ok:
            state["auth_step"] = None
            set_bot_state(user_id, state)
            send_message(chat_id, "✅ Авторизация успешна! Аккаунт подключен.", reply_markup=ik([{"text": "🚀 Начать рассылку", "callback_data": "autosend:start"}, {"text": "⬅️ Назад", "callback_data": "menu:autosend"}]))
        else:
            send_message(chat_id, f"❌ Ошибка: {err}\nПопробуйте снова.", reply_markup=ik([{"text": "🔁 Повторить", "callback_data": "autosend:connect"}, {"text": "⬅️ Назад", "callback_data": "menu:autosend"}]))
        return

    if state.get("awaiting_promo_create"):
        state["awaiting_promo_create"] = False
        set_bot_state(user_id, state)
        parts = (text or "").strip().split()
        if len(parts) < 2:
            send_message(chat_id, "Неверный формат. Примеры:\nSALE10 10 5 — +10 запросов, лимит 5\nVIP7 SUB MAX 7 1 — подписка Max 7дн, лимит 1", reply_markup=ik([{"text": "⬅️ Назад", "callback_data": "adm:promo"}]))
            return
        code = parts[0]
        if parts[1].isdigit():
            requests = int(parts[1])
            max_uses = int(parts[2]) if len(parts) > 2 else 1
            pc = create_promo_code(code, "requests", requests=requests, max_uses=max_uses, created_by=user_id)
            if pc:
                send_message(chat_id, f"✅ Промокод <code>{pc['code']}</code> создан: +{pc['requests']} запросов, лимит {pc['max_uses']}.", reply_markup=ik([{"text": "⬅️ Назад", "callback_data": "adm:promo"}]), parse_mode="HTML")
        else:
            idx = 1
            if parts[1].upper() in ("SUB", "SUBSCRIPTION"):
                idx = 2
            plan = parts[idx].upper() if idx < len(parts) else "MAX"
            days = int(parts[idx+1]) if idx+1 < len(parts) else 7
            max_uses = int(parts[idx+2]) if idx+2 < len(parts) else 1
            pc = create_promo_code(code, "subscription", plan=plan, days=days, max_uses=max_uses, created_by=user_id)
            if pc:
                send_message(chat_id, f"✅ Промокод <code>{pc['code']}</code> создан: {pc['plan'].upper()} {pc['days']}дн, лимит {pc['max_uses']}.", reply_markup=ik([{"text": "⬅️ Назад", "callback_data": "adm:promo"}]), parse_mode="HTML")
        if not pc:
            send_message(chat_id, "Не удалось создать промокод.", reply_markup=ik([{"text": "⬅️ Назад", "callback_data": "adm:promo"}]))
        else:
            send_message(chat_id, "Не удалось создать промокод.", reply_markup=ik([{"text": "⬅️ Назад", "callback_data": "adm:promo"}]))
        return

    if state.get("awaiting_promo_delete"):
        state["awaiting_promo_delete"] = False
        set_bot_state(user_id, state)
        code = (text or "").strip()
        if delete_promo_code(code):
            send_message(chat_id, f"✅ Промокод {code.upper()} удалён.", reply_markup=ik([{"text": "⬅️ Назад", "callback_data": "adm:promo"}]))
        else:
            send_message(chat_id, "Промокод не найден.", reply_markup=ik([{"text": "⬅️ Назад", "callback_data": "adm:promo"}]))
        return

    # Redeem promo code via command or awaiting state
    low = (text or "").strip().lower()
    if state.get("awaiting_promo_redeem"):
        state["awaiting_promo_redeem"] = False
        set_bot_state(user_id, state)
        code = (text or "").strip()
        ok, msg_text = redeem_promo_code(code, user_id)
        send_message(chat_id, ("✅ " if ok else "❌ ") + msg_text, reply_markup=main_menu_kb(user_id))
        return
    if low.startswith("/promo ") or low.startswith("promo "):
        code = (text or "").strip().split(None, 1)[-1]
        ok, msg_text = redeem_promo_code(code, user_id)
        send_message(chat_id, ("✅ " if ok else "❌ ") + msg_text, reply_markup=main_menu_kb(user_id))
        return

    if state.get("awaiting_broadcast"):
        state["awaiting_broadcast"] = False
        set_bot_state(user_id, state)
        raw = (text or "").strip()
        if not raw:
            send_message(chat_id, "Пустое сообщение.", reply_markup=admin_menu_kb())
            return
        # parse buttons
        import re as _re
        btn_rows = []
        # btnrow
        for m in _re.finditer(r"\[btnrow:([^]]+)\]", raw):
            parts = [p.strip() for p in m.group(1).split(",")]
            row = []
            for part in parts:
                if "|" in part:
                    t, u = part.split("|", 1)
                    row.append({"text": t.strip(), "url": u.strip()})
            if row:
                btn_rows.append(row)
        # btn (single per line) - collect remaining
        single_btns = []
        for m in _re.finditer(r"\[btn:([^]]+)\]", raw):
            part = m.group(1)
            if "|" in part:
                t, u = part.split("|", 1)
                single_btns.append([{"text": t.strip(), "url": u.strip()}])
        # remove tags from text
        clean_text = _re.sub(r"\[btn[^]]*\]", "", raw).strip()
        # build keyboard
        kb_rows = btn_rows + single_btns
        reply_markup = ik(kb_rows) if kb_rows else None
        # store pending
        state["pending_broadcast"] = {"text": clean_text, "kb_rows": kb_rows}
        set_bot_state(user_id, state)
        preview = clean_text[:500]
        send_message(chat_id, f"📢 <b>Предпросмотр рассылки:</b>\n\n{escape_html(preview)}\n\nОтправить всем?", reply_markup=ik([{"text": "✅ Отправить", "callback_data": "adm:broadcast:confirm"}, {"text": "❌ Отмена", "callback_data": "adm:show"}]), parse_mode="HTML")
        return

    if state.get("promo_step") == "name":
        code = (text or "").strip().upper()
        if not code:
            send_message(chat_id, "Введите название кода:", reply_markup=ik([{"text": "Отмена", "callback_data": "adm:promo"}]))
            return
        state["promo_data"] = {"name": code}
        state["promo_step"] = "type"
        set_bot_state(user_id, state)
        rows = [[{"text": "📊 Запросы", "callback_data": "promo:type:req"}, {"text": "💎 Подписка", "callback_data": "promo:type:sub"}],
                [{"text": "❌ Отмена", "callback_data": "adm:promo"}]]
        send_message(chat_id, f"Шаг 2/4: Тип промокода для <code>{code}</code>:", reply_markup=ik(rows), parse_mode="HTML")
        return

    # custom inputs
    if state.get("promo_step") == "req_amount_custom":
        try:
            val = int((text or "").strip())
        except ValueError:
            send_message(chat_id, "Введите число:", reply_markup=ik([{"text": "Отмена", "callback_data": "adm:promo"}]))
            return
        state["promo_data"]["requests"] = val
        state["promo_step"] = "req_limit"
        set_bot_state(user_id, state)
        rows = [[{"text": "1", "callback_data": "promo:limit:1"}, {"text": "3", "callback_data": "promo:limit:3"}, {"text": "5", "callback_data": "promo:limit:5"}],
                [{"text": "10", "callback_data": "promo:limit:10"}, {"text": "✏️ Своё", "callback_data": "promo:limit:custom"}],
                [{"text": "❌ Отмена", "callback_data": "adm:promo"}]]
        send_message(chat_id, "Шаг 4/4: Лимит использований:", reply_markup=ik(rows), parse_mode="HTML")
        return

    if state.get("promo_step") == "sub_days_custom":
        try:
            val = int((text or "").strip())
        except ValueError:
            send_message(chat_id, "Введите число дней:", reply_markup=ik([{"text": "Отмена", "callback_data": "adm:promo"}]))
            return
        state["promo_data"]["days"] = val
        state["promo_step"] = "sub_limit"
        set_bot_state(user_id, state)
        rows = [[{"text": "1", "callback_data": "promo:limit:1"}, {"text": "3", "callback_data": "promo:limit:3"}, {"text": "5", "callback_data": "promo:limit:5"}],
                [{"text": "10", "callback_data": "promo:limit:10"}, {"text": "✏️ Своё", "callback_data": "promo:limit:custom"}],
                [{"text": "❌ Отмена", "callback_data": "adm:promo"}]]
        send_message(chat_id, "Шаг 5/5: Лимит использований:", reply_markup=ik(rows), parse_mode="HTML")
        return

    if state.get("promo_step") == "limit_custom":
        try:
            val = int((text or "").strip())
        except ValueError:
            send_message(chat_id, "Введите число:", reply_markup=ik([{"text": "Отмена", "callback_data": "adm:promo"}]))
            return
        state["promo_data"]["max_uses"] = val
        _finalize_promo(user_id, chat_id, None, state)
        return

    if state.get("awaiting_user_search"):
        state["awaiting_user_search"] = False
        state["user_search"] = (text or "").strip()
        state["users_page"] = 0
        set_bot_state(user_id, state)
        send_message(chat_id, f"🔍 Поиск: {text}", reply_markup=ik([{"text": "⬅️ Админ-панель", "callback_data": "adm:show"}]))
        return

    if state.get("awaiting_subs_range"):
        state["awaiting_subs_range"] = False
        raw = (text or "").strip().replace(",", " ").replace("—", "-").replace("–", "-")
        parts = [p for p in raw.split() if p]
        try:
            if not parts:
                raise ValueError
            if len(parts) == 1:
                mn = int(parts[0])
                mx = None
            else:
                mn = int(parts[0])
                mx = int(parts[1])
            if mn < 0:
                mn = 0
            if mx is not None and mx <= 0:
                mx = None
            if mx is not None and mn > mx:
                mn, mx = mx, mn
            if mn == 0 and mx == 0:
                state["subs_min"] = None
                state["subs_max"] = None
            else:
                state["subs_min"] = mn
                state["subs_max"] = mx
            set_bot_state(user_id, state)
            send_message(chat_id, f"✅ Фильтр подписчиков: {_subs_label(state)}", reply_markup=search_filters_kb(state))
        except Exception:
            set_bot_state(user_id, state)
            send_message(chat_id, "Некорректный формат. Пример: <code>1000 50000</code> (от и до), <code>5000</code> (от 5000), <code>0 1000</code> (до 1000).", parse_mode="HTML", reply_markup=search_filters_kb(state))
        return

    if state.get("awaiting_query"):
        state["awaiting_query"] = False
        set_bot_state(user_id, state)
        if not text:
            send_message(chat_id, "Пустой запрос. Отправьте текст запроса.", reply_markup=search_filters_kb(state))
            return
        send_message(chat_id, "⏳ Ищу каналы, подождите...")
        handle_search_query(chat_id, user_id, text)
        return

    # no active process/command - ignore silently (search only via explicit flow)
    return


def handle_search_query(chat_id, user_id, query):
    state = get_bot_state(user_id) or {}
    s = get_settings()
    rem = remaining_today(user_id)
    if rem <= 0:
        text = (
            "⛔ Дневной лимит исчерпан.\n\n"
            f"Free: {int(s.get('freeLimit',5))}/день, Pro: {int(s.get('proLimit',50))}/день, Max: {int(s.get('maxLimit',100))}/день.\n"
            "Улучшите тариф в разделе «Оплата»."
        )
        send_message(chat_id, text, reply_markup=pay_kb())
        return
    limit = min(rem, 50)
    try:
        days = state.get("days") or None
        if days:
            days = int(days)
        desired = int(state.get("count") or 5)
        if desired < 1:
            desired = 5
        if desired > 15:
            desired = 15
        req_limit = min(limit, desired)
        if req_limit < desired:
            send_message(chat_id, f"⚠️ Запрошено {desired}, но осталось только {rem} запросов по лимиту. Ищем {req_limit}.", parse_mode="HTML")
        # progress message
        prog_msg = send_message(chat_id, "🔍 Ищем каналы... •••", parse_mode="HTML")
        prog_id = (prog_msg or {}).get("result", {}).get("message_id") if isinstance(prog_msg, dict) else None
        # fallback if send_message returns differently
        if prog_id is None and isinstance(prog_msg, dict):
            prog_id = prog_msg.get("message_id")
        dots = ["•••", "••○", "•○○", "○○○"]
        di = [0]
        def progress_cb(found, total):
            di[0] = (di[0] + 1) % len(dots)
            shown_found = min(found, total)
            left = max(0, total - shown_found)
            extra = ""
            if left == 1:
                extra = "\nОсталось немного..."
            elif left == 0:
                extra = "\nПочти готово..."
            text = f"🔍 Ищем каналы... {dots[di[0]]}\nНайдено: {shown_found} / {total}\nОсталось: {left}{extra}"
            if prog_id:
                edit_message(chat_id, prog_id, text, parse_mode="HTML")
        results = search_channels(
            query=query,
            days=days,
            require_channel_link=bool(state.get("require_channel_link")),
            require_recent_link=bool(state.get("require_recent_link")),
            limit=req_limit,
            language=state.get("language"),
            progress_cb=progress_cb,
        )
        # delete progress message
        if prog_id:
            try:
                api("deleteMessage", {"chat_id": chat_id, "message_id": prog_id})
            except Exception:
                pass
    except Exception as e:
        send_message(chat_id, f"❌ Ошибка поиска: {e}", reply_markup=main_menu_kb(user_id))
        return

    shown = results[:rem]
    add_usage(user_id, len(shown))

    try:
        st2 = get_bot_state(user_id) or {}
        st2["last_results"] = [
            {
                "title": c.get("title"),
                "url": c.get("url"),
                "links": _compact_links(c)[:10],
            }
            for c in shown[:50]
        ]
        st2["last_query"] = query
        set_bot_state(user_id, st2)
        state = st2
    except Exception:
        pass

    try:
        record_search(user_id, {
            "query": query,
            "filters": {
                "days": days,
                "require_channel_link": bool(state.get("require_channel_link")),
                "require_recent_link": bool(state.get("require_recent_link")),
            },
            "count": len(shown),
            "results": [
                {
                    "title": c.get("title"),
                    "url": c.get("url"),
                    "links": (c.get("links") or [])[:10],
                    "subscribers": c.get("subscribers"),
                    "lastActivity": (c.get("recentVideos") or [{}])[0].get("publishedAt"),
                }
                for c in shown[:20]
            ],
        })
    except Exception:
        pass

    if not shown:
        send_message(chat_id, "Ничего не найдено по заданным фильтрам. Попробуйте изменить запрос или период.", reply_markup=search_filters_kb(state))
        return

    desc_cnt = sum(1 for c in shown if c.get("linkInChannelDescription"))
    vid_cnt = sum(1 for c in shown if c.get("linkInRecentVideos") and not c.get("linkInChannelDescription"))
    none_cnt = sum(1 for c in shown if not c.get("linkInChannelDescription") and not c.get("linkInRecentVideos"))
    header = (
        f"🔎 <b>Поиск: «{escape_html(query)}»</b>\n\n"
        f"Найдено: {len(shown)} / {desired}\n"
        f"🔗 В описании/профиле: {desc_cnt}\n"
        f"🎬 Только в видео: {vid_cnt}\n"
        f"❌ Без ссылок: {none_cnt}\n"
    )
    chunks = [header]
    for i, c in enumerate(shown, 1):
        chunks.append(format_channel(c, i))
    text_out = "\n\n".join(chunks)

    res_kb = ik([
        [{"text": "📋 Ссылки списком", "callback_data": "res:copylinks"}],
        [{"text": "🔎 Новый поиск", "callback_data": "menu:search"}, {"text": "🏠 Меню", "callback_data": "menu:home"}],
    ])

    if len(text_out) > 3800:
        cur = header
        for i, c in enumerate(shown, 1):
            line = "\n\n" + format_channel(c, i)
            if len(cur) + len(line) > 3800:
                send_message(chat_id, cur, parse_mode="HTML")
                cur = line.lstrip()
            else:
                cur += line
        if cur.strip():
            send_message(chat_id, cur, parse_mode="HTML", reply_markup=res_kb)
    else:
        send_message(chat_id, text_out, parse_mode="HTML", reply_markup=res_kb)


def run_polling(poll_timeout=25):
    if not TELEGRAM_BOT_TOKEN:
        raise RuntimeError("TELEGRAM_BOT_TOKEN не задан (проверьте .env)")
    offset = None
    print("ClientFy bot polling started")
    while True:
        try:
            params = {"timeout": poll_timeout}
            if offset is not None:
                params["offset"] = offset
            resp = api("getUpdates", params)
            if not resp.get("ok"):
                desc = resp.get("description", "unknown error")
                print("getUpdates error:", desc)
                time.sleep(3)
                continue
            for upd in resp.get("result", []):
                offset = upd["update_id"] + 1
                try:
                    handle_update(upd)
                except Exception:
                    traceback.print_exc()
        except KeyboardInterrupt:
            print("Stopping bot")
            break
        except Exception:
            traceback.print_exc()
            time.sleep(3)


if __name__ == "__main__":
    try:
        n = migrate_legacy_sessions()
        if n:
            print(f"Migrated {n} legacy sessions -> needs_reauth")
    except Exception as e:
        print("Migration error:", e)
    run_polling()
