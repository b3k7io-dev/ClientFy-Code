import json
import threading
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Any, Dict

from config import (
    DATA_FILE, FREE_LIMIT, PRO_LIMIT, PRO_PRICE_USD, PRO_PRICE_STARS,
    MAX_LIMIT, MAX_PRICE_USD, MAX_PRICE_STARS, SUPPORT_URL, TELEGRAM_CHANNEL_URL,
)

_lock = threading.Lock()


def _today() -> str:
    # Usage day resets at midnight Pacific Time (YouTube quota reset)
    try:
        from zoneinfo import ZoneInfo
        tz = ZoneInfo("America/Los_Angeles")
    except Exception:
        tz = timezone(timedelta(hours=-8))
    now = datetime.now(tz)
    return now.date().strftime("%Y-%m-%d")


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _default() -> Dict[str, Any]:
    return {
        "settings": {
            "cardRequisites": "Уточните реквизиты у администратора",
            "proPriceUsd": PRO_PRICE_USD,
            "proPriceStars": PRO_PRICE_STARS,
            "maxPriceUsd": MAX_PRICE_USD,
            "maxPriceStars": MAX_PRICE_STARS,
            "freeLimit": FREE_LIMIT,
            "proLimit": PRO_LIMIT,
            "maxLimit": MAX_LIMIT,
            "supportUrl": SUPPORT_URL,
            "channelUrl": TELEGRAM_CHANNEL_URL,
            "maintenanceMode": False,
        },
        "users": {},
        "usage": {},
        "payments": [],
        "bot_state": {},
        "search_history": {},
        "payment_apps": [],
        "next_app_id": 1,
    }


def ensure_file() -> None:
    DATA_FILE.parent.mkdir(parents=True, exist_ok=True)
    if not DATA_FILE.exists():
        DATA_FILE.write_text(json.dumps(_default(), ensure_ascii=False, indent=2), encoding="utf-8")


def read() -> Dict[str, Any]:
    ensure_file()
    try:
        data = json.loads(DATA_FILE.read_text(encoding="utf-8"))
    except Exception:
        data = _default()
    # migrate missing keys
    base = _default()
    for k, v in base.items():
        if k not in data:
            data[k] = v
    if "settings" not in data or not isinstance(data["settings"], dict):
        data["settings"] = base["settings"]
    for k, v in base["settings"].items():
        data["settings"].setdefault(k, v)
    if "search_history" not in data or not isinstance(data["search_history"], dict):
        data["search_history"] = {}
    if "autosend" not in data or not isinstance(data["autosend"], dict):
        data["autosend"] = {}
    # migrate settings
    if "settings" in data and isinstance(data["settings"], dict):
        data["settings"].setdefault("maintenanceMode", False)
    if "payment_apps" not in data or not isinstance(data["payment_apps"], list):
        data["payment_apps"] = []
    if "next_app_id" not in data:
        # derive from existing apps
        mx = 0
        for a in data.get("payment_apps") or []:
            try:
                mx = max(mx, int(a.get("id") or 0))
            except Exception:
                pass
        data["next_app_id"] = mx + 1
    if "autosend" not in data or not isinstance(data["autosend"], dict):
        data["autosend"] = {}
    return data


def write(data: Dict[str, Any]) -> None:
    ensure_file()
    tmp = DATA_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(DATA_FILE)


def get_settings() -> Dict[str, Any]:
    with _lock:
        d = read()
        return dict(d.get("settings", {}))


def update_settings(patch: Dict[str, Any]) -> Dict[str, Any]:
    with _lock:
        d = read()
        d.setdefault("settings", {})
        d["settings"].update(patch)
        write(d)
        return dict(d["settings"])


def _effective_plan(u: Dict[str, Any]) -> str:
    plan = u.get("plan", "free")
    if plan in ("pro", "max"):
        exp = u.get("planExpiresAt") or u.get("proExpiresAt")
        if exp:
            try:
                dt = datetime.fromisoformat(str(exp).replace("Z", "+00:00"))
                if dt <= datetime.now(timezone.utc):
                    return "free"
            except Exception:
                pass
    return plan


def get_user(user_id: str, name: str = None, username: str = None) -> Dict[str, Any]:
    with _lock:
        d = read()
        d.setdefault("users", {})
        if user_id not in d["users"]:
            d["users"][user_id] = {"id": user_id, "plan": "free", "createdAt": _now_iso(), "blocked": False, "name": name or "", "username": username or ""}
            write(d)
            return dict(d["users"][user_id])
        u = d["users"][user_id]
        # ensure blocked field exists
        if "blocked" not in u:
            u["blocked"] = False
        # update name/username if provided
        if name and name != u.get("name"):
            u["name"] = name
        if username and username != u.get("username"):
            u["username"] = username
        d["users"][user_id] = u
        write(d)
        # auto-downgrade expired paid plans
        if u.get("plan") in ("pro", "max"):
            eff = _effective_plan(u)
            if eff == "free":
                old = u.get("plan")
                u["plan"] = "free"
                u["planExpiredAt"] = _now_iso()
                u["expiredPlan"] = old
                u.pop("planExpiresAt", None)
                u.pop("proExpiresAt", None)
                u["updatedAt"] = _now_iso()
                d["users"][user_id] = u
                write(d)
        else:
            # normalize legacy/unknown plan names
            if u.get("plan") not in ("free", "pro", "max"):
                u["plan"] = "free"
                d["users"][user_id] = u
                write(d)
        return dict(d["users"][user_id])


def set_plan(user_id: str, plan: str, days: int = 30) -> Dict[str, Any]:
    with _lock:
        d = read()
        d.setdefault("users", {})
        u = d["users"].get(user_id, {"id": user_id, "createdAt": _now_iso(), "blocked": False})
        plan = (plan or "free").lower().strip()
        if plan not in ("free", "pro", "max"):
            plan = "free"
        u["plan"] = plan
        u["updatedAt"] = _now_iso()
        if "blocked" not in u:
            u["blocked"] = False
        if plan in ("pro", "max"):
            exp = datetime.now(timezone.utc) + timedelta(days=max(1, int(days or 30)))
            u["planExpiresAt"] = exp.isoformat()
            u.pop("proExpiresAt", None)
            u.pop("planExpiredAt", None)
            u.pop("expiredPlan", None)
        else:
            u.pop("planExpiresAt", None)
            u.pop("proExpiresAt", None)
        d["users"][user_id] = u
        write(d)
        return dict(u)


def block_user(user_id: str, blocked: bool = True) -> Dict[str, Any]:
    with _lock:
        d = read()
        d.setdefault("users", {})
        u = d["users"].get(user_id, {"id": user_id, "createdAt": _now_iso(), "blocked": False, "plan": "free"})
        u["blocked"] = bool(blocked)
        u["updatedAt"] = _now_iso()
        d["users"][user_id] = u
        write(d)
        return dict(u)


def is_blocked(user_id: str) -> bool:
    with _lock:
        d = read()
        u = (d.get("users") or {}).get(str(user_id), {})
        return bool(u.get("blocked", False))


def get_usage(user_id: str) -> int:
    with _lock:
        d = read()
        key = f"{user_id}:{_today()}"
        return int((d.get("usage") or {}).get(key, 0))


def add_usage(user_id: str, count: int) -> int:
    with _lock:
        d = read()
        d.setdefault("usage", {})
        key = f"{user_id}:{_today()}"
        d["usage"][key] = int(d["usage"].get(key, 0)) + int(count)
        # light cleanup: keep only recent days
        keys = list(d["usage"].keys())
        if len(keys) > 5000:
            for k in sorted(keys)[:-2000]:
                d["usage"].pop(k, None)
        write(d)
        return int(d["usage"][key])


def grant_requests(user_id: str, count: int) -> int:
    """Decrease today's used count by count (grant extra searches). Returns new used count."""
    with _lock:
        d = read()
        d.setdefault("usage", {})
        key = f"{user_id}:{_today()}"
        new_used = max(0, int(d["usage"].get(key, 0)) - int(count))
        d["usage"][key] = new_used
        write(d)
        return new_used


def reset_usage(user_id: str) -> int:
    with _lock:
        d = read()
        d.setdefault("usage", {})
        key = f"{user_id}:{_today()}"
        d["usage"][key] = 0
        write(d)
        return 0


def plan_limit(user_id: str) -> int:
    s = get_settings()
    u = get_user(user_id)
    plan = u.get("plan", "free")
    if plan == "max":
        return int(s.get("maxLimit", MAX_LIMIT))
    if plan == "pro":
        return int(s.get("proLimit", PRO_LIMIT))
    return int(s.get("freeLimit", FREE_LIMIT))


def remaining_today(user_id: str) -> int:
    return max(0, plan_limit(user_id) - get_usage(user_id))


def record_payment(payment: Dict[str, Any]) -> None:
    with _lock:
        d = read()
        d.setdefault("payments", [])
        p = dict(payment)
        p["at"] = datetime.now(timezone.utc).isoformat()
        d["payments"].insert(0, p)
        d["payments"] = d["payments"][:200]
        write(d)


def list_payments(limit: int = 50):
    with _lock:
        d = read()
        return list((d.get("payments") or [])[:limit])


def record_search(user_id: str, entry: Dict[str, Any]) -> None:
    with _lock:
        d = read()
        d.setdefault("search_history", {})
        hist = d["search_history"].setdefault(user_id, [])
        e = dict(entry)
        e["at"] = datetime.now(timezone.utc).isoformat()
        hist.insert(0, e)
        d["search_history"][user_id] = hist[:100]
        write(d)


def get_history(user_id: str, limit: int = 50):
    with _lock:
        d = read()
        hist = (d.get("search_history") or {}).get(user_id, [])
        return list(hist[:limit])


def all_users_summary():
    with _lock:
        d = read()
        users = d.get("users") or {}
        usage = d.get("usage") or {}
        history = d.get("search_history") or {}
        today = _today()
        out = []
        for uid, u in users.items():
            used_today = int(usage.get(f"{uid}:{today}", 0))
            hist = history.get(uid) or []
            total_searches = len(hist)
            total_found = sum(int(e.get("count") or 0) for e in hist)
            last_at = hist[0].get("at") if hist else u.get("updatedAt") or u.get("createdAt")
            plan = u.get("plan", "free")
            out.append({
            "id": uid,
            "plan": plan,
            "used_today": used_today,
            "total_searches": total_searches,
            "total_found": total_found,
            "last_at": last_at,
            "blocked": bool(u.get("blocked", False)),
        })
        # sort: most active today, then total searches
        out.sort(key=lambda x: (x["used_today"], x["total_searches"], x["total_found"]), reverse=True)
        return out


def global_stats():
    with _lock:
        d = read()
        users = d.get("users") or {}
        usage = d.get("usage") or {}
        history = d.get("search_history") or {}
        today = _today()
        total_users = len(users)
        pro_users = sum(1 for u in users.values() if u.get("plan") == "pro")
        max_users = sum(1 for u in users.values() if u.get("plan") == "max")
        searches_today = sum(1 for k in usage.keys() if k.endswith(f":{today}") and int(usage.get(k, 0)) > 0)
        found_today = sum(int(v) for k, v in usage.items() if k.endswith(f":{today}"))
        total_searches = sum(len(v or []) for v in history.values())
        total_found = 0
        est_units = 0
        for hist in history.values():
            for e in (hist or []):
                c = int(e.get("count") or 0)
                total_found += c
                # rough estimate: search.list(video)+search.list(channel)+channels.list + up to ~N playlistItems calls
                est_units += 101 + 101 + 1 + max(c, 1)
        free_users = total_users - pro_users - max_users
        return {
            "total_users": total_users,
            "pro_users": pro_users,
            "max_users": max_users,
            "free_users": max(0, free_users),
            "search_users_today": searches_today,
            "channels_found_today": found_today,
            "total_searches": total_searches,
            "total_channels_found": total_found,
            "est_quota_units": est_units,
        }


def create_payment_app(user_id: str, username: str, name: str, file_id: str, file_type: str, message_id: int = None, plan: str = "pro", payment_method: str = "card") -> Dict[str, Any]:
    with _lock:
        d = read()
        d.setdefault("payment_apps", [])
        app_id = int(d.get("next_app_id") or 1)
        d["next_app_id"] = app_id + 1
        plan = (plan or "pro").lower().strip()
        if plan not in ("pro", "max"):
            plan = "pro"
        app = {
            "id": app_id,
            "user_id": str(user_id),
            "username": username or "",
            "name": name or "",
            "file_id": file_id,
            "file_type": file_type,  # photo or document
            "message_id": message_id,
            "plan": plan,
            "payment_method": payment_method,
            "status": "pending",  # pending/approved/rejected
            "admin_note": "",
            "created_at": datetime.now(timezone.utc).isoformat(),
            "updated_at": None,
        }
        d["payment_apps"].insert(0, app)
        d["payment_apps"] = d["payment_apps"][:300]
        write(d)
        return dict(app)


def list_payment_apps(status: str = None, limit: int = 30):
    with _lock:
        d = read()
        apps = list(d.get("payment_apps") or [])
        if status:
            apps = [a for a in apps if a.get("status") == status]
        return apps[:limit]


def list_user_payment_apps(user_id: str, limit: int = 20):
    with _lock:
        d = read()
        apps = [a for a in (d.get("payment_apps") or []) if str(a.get("user_id")) == str(user_id)]
        return apps[:limit]


def get_payment_app(app_id: int):
    with _lock:
        d = read()
        for a in (d.get("payment_apps") or []):
            if int(a.get("id") or 0) == int(app_id):
                return dict(a)
        return None


def update_payment_app(app_id: int, patch: Dict[str, Any]):
    with _lock:
        d = read()
        apps = d.get("payment_apps") or []
        for i, a in enumerate(apps):
            if int(a.get("id") or 0) == int(app_id):
                na = dict(a)
                na.update(patch)
                na["updated_at"] = datetime.now(timezone.utc).isoformat()
                apps[i] = na
                d["payment_apps"] = apps
                write(d)
                return dict(na)
        return None


def get_bot_state(user_id: str) -> Dict[str, Any]:
    with _lock:
        d = read()
        return dict((d.get("bot_state") or {}).get(user_id, {}))


def set_bot_state(user_id: str, state: Dict[str, Any]) -> None:
    with _lock:
        d = read()
        d.setdefault("bot_state", {})
        if state:
            d["bot_state"][user_id] = state
        else:
            d["bot_state"].pop(user_id, None)
        write(d)


def get_autosend(user_id: str) -> Dict[str, Any]:
    with _lock:
        d = read()
        cfg = (d.get("autosend") or {}).get(str(user_id), {})
        return {
            "template": cfg.get("template") or "Здравствуйте! Увидел ваш канал «{title}» ({url}) — хотел предложить сотрудничество.",
            "topics": list(cfg.get("topics") or []),
            "session_string": cfg.get("session_string"),
            "phone_code_hash": cfg.get("phone_code_hash"),
        }


def set_autosend(user_id: str, patch: Dict[str, Any]) -> Dict[str, Any]:
    with _lock:
        d = read()
        d.setdefault("autosend", {})
        cur = d["autosend"].get(str(user_id), {})
        cur.update(patch or {})
        d["autosend"][str(user_id)] = cur
        write(d)
        # Return without calling get_autosend (which also acquires lock)
        cfg = d["autosend"].get(str(user_id), {})
        return {
            "template": cfg.get("template") or "Здравствуйте! Увидел ваш канал «{title}» ({url}) — хотел предложить сотрудничество.",
            "topics": list(cfg.get("topics") or []),
            "session_string": cfg.get("session_string"),
            "phone_code_hash": cfg.get("phone_code_hash"),
        }


def set_autosend_creds(user_id: str, api_id: int, api_hash: str, phone: str) -> Dict[str, Any]:
    with _lock:
        d = read()
        d.setdefault("autosend", {})
        cur = d["autosend"].get(str(user_id), {})
        cur.update({"api_id": api_id, "api_hash": api_hash, "phone": phone})
        d["autosend"][str(user_id)] = cur
        write(d)
        cfg = d["autosend"].get(str(user_id), {})
        return {
            "template": cfg.get("template") or "Здравствуйте! Увидел ваш канал «{title}» ({url}) — хотел предложить сотрудничество.",
            "topics": list(cfg.get("topics") or []),
            "session_string": cfg.get("session_string"),
            "phone_code_hash": cfg.get("phone_code_hash"),
        }


def get_autosend_creds(user_id: str) -> Dict[str, Any]:
    with _lock:
        d = read()
        cfg = (d.get("autosend") or {}).get(str(user_id), {})
        return {
            "api_id": cfg.get("api_id"),
            "api_hash": cfg.get("api_hash"),
            "phone": cfg.get("phone"),
        }


# ---------- Telegram account sessions (encrypted at rest) ----------

def set_telegram_session(user_id: str, phone: str, session_blob: str, api_id=None, api_hash=None) -> None:
    """Store an encrypted session blob + metadata for a connected Telegram account."""
    with _lock:
        d = read()
        d.setdefault("autosend", {})
        cur = d["autosend"].get(str(user_id), {})
        cur.update({
            "phone": phone,
            "session_string": session_blob,  # encrypted blob
            "session_encrypted": True,
            "connected_at": _now_iso(),
            "needs_reauth": False,
        })
        if api_id is not None:
            cur["api_id"] = api_id
        if api_hash is not None:
            cur["api_hash"] = api_hash
        # clear transient auth state
        cur.pop("phone_code_hash", None)
        d["autosend"][str(user_id)] = cur
        write(d)


def get_telegram_session(user_id: str) -> Dict[str, Any]:
    with _lock:
        d = read()
        cfg = (d.get("autosend") or {}).get(str(user_id), {})
        return {
            "phone": cfg.get("phone"),
            "session_string": cfg.get("session_string"),
            "session_encrypted": bool(cfg.get("session_encrypted")),
            "connected_at": cfg.get("connected_at"),
            "needs_reauth": bool(cfg.get("needs_reauth")),
            "api_id": cfg.get("api_id"),
            "api_hash": cfg.get("api_hash"),
        }


def delete_telegram_session(user_id: str) -> None:
    with _lock:
        d = read()
        cfg = (d.get("autosend") or {}).get(str(user_id), {})
        for k in ("phone", "session_string", "session_encrypted", "connected_at",
                  "phone_code_hash", "needs_reauth"):
            cfg.pop(k, None)
        d.setdefault("autosend", {})[str(user_id)] = cfg
        write(d)


def mark_needs_reauth(user_id: str) -> None:
    with _lock:
        d = read()
        d.setdefault("autosend", {})
        cur = d["autosend"].get(str(user_id), {})
        cur["needs_reauth"] = True
        cur.pop("session_string", None)
        d["autosend"][str(user_id)] = cur
        write(d)


def migrate_legacy_sessions() -> int:
    """Mark old (plaintext/Pyrogram) sessions as requiring re-auth. Returns count."""
    n = 0
    with _lock:
        d = read()
        for uid, cfg in (d.get("autosend") or {}).items():
            if cfg.get("session_string") and not cfg.get("session_encrypted"):
                cfg["needs_reauth"] = True
                cfg.pop("session_string", None)
                cfg.pop("phone_code_hash", None)
                n += 1
        write(d)
    return n


# ---------- Promo codes ----------

def _promo_default() -> Dict[str, Any]:
    return {}


def create_promo_code(code: str, promo_type: str = "requests", requests: int = 10, plan: str = "max", days: int = 7, max_uses: int = 1, created_by: str = "") -> Dict[str, Any]:
    code = (code or "").strip().upper()
    if not code:
        return {}
    promo_type = (promo_type or "requests").lower()
    if promo_type not in ("requests", "subscription"):
        promo_type = "requests"
    with _lock:
        d = read()
        d.setdefault("promo_codes", {})
        entry = {
            "code": code,
            "type": promo_type,
            "max_uses": max(1, int(max_uses or 1)),
            "used_by": [],
            "created_by": created_by,
            "created_at": _now_iso(),
        }
        if promo_type == "requests":
            entry["requests"] = max(1, int(requests or 10))
        else:
            entry["plan"] = plan if plan in ("pro", "max") else "max"
            entry["days"] = max(1, int(days or 7))
        d["promo_codes"][code] = entry
        write(d)
        return dict(d["promo_codes"][code])


def get_promo_code(code: str) -> Optional[Dict[str, Any]]:
    code = (code or "").strip().upper()
    with _lock:
        d = read()
        pc = (d.get("promo_codes") or {}).get(code)
        return dict(pc) if pc else None


def list_promo_codes() -> List[Dict[str, Any]]:
    with _lock:
        d = read()
        return [dict(v) for v in (d.get("promo_codes") or {}).values()]


def redeem_promo_code(code: str, user_id: str) -> (bool, str):
    code = (code or "").strip().upper()
    with _lock:
        d = read()
        d.setdefault("promo_codes", {})
        pc = d["promo_codes"].get(code)
        if not pc:
            return False, "Промокод не найден."
        if user_id in (pc.get("used_by") or []):
            return False, "Вы уже использовали этот промокод."
        if len(pc.get("used_by") or []) >= int(pc.get("max_uses") or 1):
            return False, "Лимит использований исчерпан."
        ptype = pc.get("type") or "requests"
        if ptype == "requests":
            reqs = int(pc.get("requests") or 10)
            d.setdefault("usage", {})
            key = f"{user_id}:{_today()}"
            cur_used = int(d["usage"].get(key, 0))
            d["usage"][key] = max(0, cur_used - reqs)
            pc.setdefault("used_by", []).append(user_id)
            d["promo_codes"][code] = pc
            write(d)
            return True, f"Промокод активирован! +{reqs} запросов."
        else:
            plan = pc.get("plan") or "max"
            days = int(pc.get("days") or 7)
            u = d["users"].get(user_id, {"id": user_id, "createdAt": _now_iso(), "blocked": False})
            u["plan"] = plan
            u["updatedAt"] = _now_iso()
            if "blocked" not in u:
                u["blocked"] = False
            exp = datetime.now(timezone.utc) + timedelta(days=max(1, days))
            u["planExpiresAt"] = exp.isoformat()
            d["users"][user_id] = u
            pc.setdefault("used_by", []).append(user_id)
            d["promo_codes"][code] = pc
            write(d)
            return True, f"Промокод активирован! Тариф {plan.upper()} на {days} дн."


def delete_promo_code(code: str) -> bool:
    code = (code or "").strip().upper()
    with _lock:
        d = read()
        if code in (d.get("promo_codes") or {}):
            del d["promo_codes"][code]
            write(d)
            return True
        return False
