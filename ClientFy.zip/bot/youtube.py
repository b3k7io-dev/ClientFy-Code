import json
import re
import urllib.parse
import urllib.request
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional

from config import YOUTUBE_API_KEY

API = "https://www.googleapis.com/youtube/v3"
URL_RE = re.compile(r"(https?://[^\s)\"'<>]+|www\.[^\s)\"'<>]+|t\.me/[^\s)\"'<>]+)", re.I)
DUR_RE = re.compile(r"PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?")
SHORT_MAX_SECONDS = 60  # YouTube Shorts: <= 60s treated as short


def _get(path: str, params: Dict[str, Any]) -> Dict[str, Any]:
    if not YOUTUBE_API_KEY:
        raise RuntimeError("YOUTUBE_API_KEY не задан")
    q = dict(params)
    q["key"] = YOUTUBE_API_KEY
    url = API + path + "?" + urllib.parse.urlencode({k: v for k, v in q.items() if v is not None and v != ""})
    req = urllib.request.Request(url, headers={"User-Agent": "ClientFyBot/1.0"})
    try:
        with urllib.request.urlopen(req, timeout=20) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", "ignore")
        try:
            data = json.loads(body)
            msg = data.get("error", {}).get("message") or body
        except Exception:
            msg = body or str(e)
        raise RuntimeError(f"YouTube API: {msg}")


def has_link(text: str = "") -> bool:
    return bool(URL_RE.search(text or ""))


def extract_links(text: str = "") -> List[str]:
    return list(dict.fromkeys(m.group(1) for m in URL_RE.finditer(text or "")))


def days_ago_iso(days: int) -> str:
    return (datetime.now(timezone.utc) - timedelta(days=int(days))).isoformat().replace("+00:00", "Z")


def parse_duration_seconds(iso_dur: str) -> Optional[int]:
    if not iso_dur:
        return None
    m = DUR_RE.fullmatch(iso_dur)
    if not m:
        return None
    h = int(m.group(1) or 0)
    mn = int(m.group(2) or 0)
    s = int(m.group(3) or 0)
    return h * 3600 + mn * 60 + s


def is_short_video(content_details: Dict[str, Any]) -> bool:
    dur = parse_duration_seconds((content_details or {}).get("duration") or "")
    if dur is None:
        return False  # if unknown, don't exclude
    return dur <= SHORT_MAX_SECONDS


def get_video_details(video_ids: List[str]) -> Dict[str, Dict[str, Any]]:
    # returns {video_id: item}
    out: Dict[str, Dict[str, Any]] = {}
    ids = [v for v in video_ids if v]
    for i in range(0, len(ids), 50):
        chunk = ids[i:i + 50]
        if not chunk:
            continue
        data = _get("/videos", {"part": "contentDetails,snippet", "id": ",".join(chunk), "maxResults": 50})
        for item in data.get("items", []):
            vid = item.get("id")
            if vid:
                out[vid] = item
    return out


def get_channels(channel_ids: List[str]) -> List[Dict[str, Any]]:
    if not channel_ids:
        return []
    data = _get("/channels", {"part": "snippet,statistics,contentDetails", "id": ",".join(channel_ids[:50]), "maxResults": 50})
    return data.get("items", [])


def get_recent_long_videos(uploads_playlist_id: str, max_results: int = 3, fetch: int = 15) -> List[Dict[str, Any]]:
    if not uploads_playlist_id:
        return []
    data = _get("/playlistItems", {"part": "snippet,contentDetails", "playlistId": uploads_playlist_id, "maxResults": max(1, min(fetch, 50))})
    items = data.get("items", [])
    # collect video ids in order
    vids = []
    for v in items:
        vs = v.get("snippet") or {}
        vid = ((vs.get("resourceId") or {}).get("videoId")) or ((v.get("contentDetails") or {}).get("videoId"))
        if vid:
            vids.append(vid)
    details = get_video_details(vids)
    long_items = []
    for v in items:
        vs = v.get("snippet") or {}
        vid = ((vs.get("resourceId") or {}).get("videoId")) or ((v.get("contentDetails") or {}).get("videoId"))
        if not vid:
            continue
        det = details.get(vid) or {}
        if is_short_video(det.get("contentDetails") or {}):
            continue
        # prefer snippet from details if playlist snippet missing description; keep playlist item
        long_items.append(v)
        if len(long_items) >= max_results:
            break
    return long_items


def norm_channel(ch: Dict[str, Any], recent_items: List[Dict[str, Any]]) -> Dict[str, Any]:
    sn = ch.get("snippet") or {}
    st = ch.get("statistics") or {}
    uploads = ((ch.get("contentDetails") or {}).get("relatedPlaylists") or {}).get("uploads")
    desc = sn.get("description") or ""
    recent = []
    for v in recent_items:
        vs = v.get("snippet") or {}
        vid = ((vs.get("resourceId") or {}).get("videoId")) or ((v.get("contentDetails") or {}).get("videoId"))
        vdesc = vs.get("description") or ""
        recent.append({
            "id": vid,
            "title": vs.get("title") or "",
            "description": vdesc,
            "publishedAt": vs.get("publishedAt"),
            "url": f"https://www.youtube.com/watch?v={vid}" if vid else None,
            "hasLink": has_link(vdesc),
        })
    link_in_channel = has_link(desc)
    link_in_recent = any(r["hasLink"] for r in recent)
    links = extract_links(desc)
    link_sources = []
    for l in extract_links(desc):
        link_sources.append({"url": l, "source": "Описание канала"})
    for i, r in enumerate(recent, 1):
        for l in extract_links(r.get("description") or ""):
            if l not in [x["url"] for x in link_sources]:
                link_sources.append({"url": l, "source": f"Видео №{i}"})
            links.append(l)
    links = list(dict.fromkeys(links))[:10]
    link_sources = link_sources[:10]
    custom = sn.get("customUrl")
    return {
        "id": ch.get("id"),
        "title": sn.get("title") or "",
        "description": desc,
        "customUrl": custom,
        "url": f"https://www.youtube.com/{custom}" if custom else f"https://www.youtube.com/channel/{ch.get('id')}",
        "publishedAt": sn.get("publishedAt"),
        "thumbnail": (((sn.get("thumbnails") or {}).get("medium") or {}).get("url")
                      or ((sn.get("thumbnails") or {}).get("default") or {}).get("url")),
        "subscribers": None if st.get("hiddenSubscriberCount") else int(st.get("subscriberCount") or 0),
        "videoCount": int(st.get("videoCount") or 0),
        "viewCount": int(st.get("viewCount") or 0),
        "uploadsPlaylistId": uploads,
        "recentVideos": recent,
        "linkInChannelDescription": link_in_channel,
        "linkInRecentVideos": link_in_recent,
        "anyLink": link_in_channel or link_in_recent,
        "links": links,
        "link_sources": link_sources,
    }


def _detect_lang(text: str) -> str:
    t = text or ""
    cyr = sum(1 for c in t if "\u0400" <= c <= "\u04FF")
    lat = sum(1 for c in t if c.isascii() and c.isalpha())
    if cyr > 5 and cyr >= lat * 0.3:
        return "ru"
    if lat > 10 and cyr == 0:
        return "en"
    return "other"


def search_channels(query: str, days: Optional[int] = None, require_channel_link: bool = False,
                    require_recent_link: bool = False, limit: int = 5,
                    subs_min: Optional[int] = None, subs_max: Optional[int] = None,
                    language: Optional[str] = None, progress_cb=None) -> List[Dict[str, Any]]:
    q = (query or "").strip()
    if not q:
        raise ValueError("Введите поисковый запрос")
    limit = max(1, min(int(limit or 5), 50))
    published_after = days_ago_iso(days) if days else None

    channel_ids: List[str] = []
    seen_ids = set()
    next_token = None
    pages = 0
    lang_code = (language or "").lower().strip()
    # map common names
    lang_map = {"русский": "ru", "russian": "ru", "ru": "ru",
                "английский": "en", "english": "en", "en": "en"}
    lang_code = lang_map.get(lang_code, lang_code)

    while len(channel_ids) < limit * 4 and pages < 6:
        pages += 1
        params = {
            "part": "snippet", "q": q, "type": "video", "order": "date",
            "maxResults": 50,
        }
        if published_after:
            params["publishedAfter"] = published_after
        if lang_code and lang_code not in ("any", "другой", "other", ""):
            params["relevanceLanguage"] = lang_code
        if next_token:
            params["pageToken"] = next_token
        try:
            vdata = _get("/search", params)
        except Exception:
            break
        search_items = vdata.get("items", [])
        search_vids = []
        for item in search_items:
            vid = (item.get("id") or {}).get("videoId")
            if vid:
                search_vids.append(vid)
        details = get_video_details(search_vids)
        for item in search_items:
            vid = (item.get("id") or {}).get("videoId")
            if not vid:
                continue
            det = details.get(vid) or {}
            if is_short_video(det.get("contentDetails") or {}):
                continue
            cid = (item.get("snippet") or {}).get("channelId")
            if cid and cid not in seen_ids:
                seen_ids.add(cid)
                channel_ids.append(cid)
        if progress_cb:
            try:
                progress_cb(len(channel_ids), limit)
            except Exception:
                pass
        next_token = vdata.get("nextPageToken")
        if not next_token:
            break

    channel_ids = channel_ids[:100]
    if not channel_ids:
        return []

    # enrich in batches of 50
    channels = []
    for i in range(0, len(channel_ids), 50):
        channels.extend(get_channels(channel_ids[i:i+50]))

    channels = get_channels(channel_ids)
    enriched = []
    for ch in channels:
        uploads = ((ch.get("contentDetails") or {}).get("relatedPlaylists") or {}).get("uploads")
        try:
            recent = get_recent_long_videos(uploads, 3, fetch=15)
        except Exception:
            recent = []
        enriched.append(norm_channel(ch, recent))

    # Language filter
    if lang_code and lang_code not in ("any", "другой", "other", ""):
        filtered = []
        for c in enriched:
            text_blob = (c.get("title") or "") + " " + (c.get("description") or "")
            for v in c.get("recentVideos") or []:
                text_blob += " " + (v.get("title") or "") + " " + (v.get("description") or "")
            det = _detect_lang(text_blob)
            if lang_code == "ru" and det == "ru":
                filtered.append(c)
            elif lang_code == "en" and det == "en":
                filtered.append(c)
            elif lang_code not in ("ru", "en"):
                filtered.append(c)
        if filtered:
            enriched = filtered

    results = enriched
    if days:
        cutoff = datetime.now(timezone.utc) - timedelta(days=int(days))

        def recent_enough(c):
            for v in c.get("recentVideos") or []:
                ts = v.get("publishedAt")
                if not ts:
                    continue
                try:
                    dt = datetime.fromisoformat(ts.replace("Z", "+00:00"))
                except Exception:
                    continue
                if dt >= cutoff:
                    return True
            return False

        results = [c for c in results if recent_enough(c)]
    if require_channel_link:
        results = [c for c in results if c.get("linkInChannelDescription")]
    if require_recent_link:
        results = [c for c in results if c.get("linkInRecentVideos")]
    if subs_min is not None or subs_max is not None:
        def ok_subs(c):
            s = c.get("subscribers")
            if s is None:
                return False
            if subs_min is not None and s < int(subs_min):
                return False
            if subs_max is not None and s > int(subs_max):
                return False
            return True

        results = [c for c in results if ok_subs(c)]

    def sort_key(c):
        ts = 0
        if c.get("recentVideos"):
            p = c["recentVideos"][0].get("publishedAt")
            if p:
                try:
                    ts = datetime.fromisoformat(p.replace("Z", "+00:00")).timestamp()
                except Exception:
                    ts = 0
        return (ts, c.get("subscribers") or 0)

    results.sort(key=sort_key, reverse=True)
    return results[:limit]
